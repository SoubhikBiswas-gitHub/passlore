// Passlore — Lore behaviour, extracted from the prototype component.
// DCLogic is the prototype runtime base class: this.props, this.state, this.setState(), componentDidMount(), renderVals() returns the values the template binds.
// Port the pure functions (rnd, sets, gen*, metrics, tier, crack, parseRules, form*, phrase, hashOf, cardSvg, cardPng) as-is; replace renderVals with React state + JSX.
class Component extends DCLogic {
  renderVals() {
    const p = this.props || {};
    const mood = p.mood || 'happy';
    const scenes = String(p.scene || 'none').split(/[ ,]+/);
    const size = Number(p.size) || 160;
    const eye = (x, y, r) => 'M' + (x - r) + ' ' + y + 'a' + r + ' ' + r + ' 0 1 0 ' + (2 * r) + ' 0a' + r + ' ' + r + ' 0 1 0 ' + (-2 * r) + ' 0';
    const open = eye(56, 66, 5) + ' ' + eye(84, 66, 5);
    const big = eye(56, 64, 6.5) + ' ' + eye(84, 64, 6.5);
    const A = {
      wave: ['M32 62Q18 48 20 32', 20, 30, 'lo-arm'],
      down: ['M32 84Q20 94 18 106', 18, 108, ''],
      up: ['M32 70Q14 64 14 48', 14, 46, ''],
      cheer: ['M34 56Q22 36 30 22', 30, 20, 'lo-arm']
    };
    const M = {
      happy: { eyesFill: open, mouth: 'M58 82Q70 94 82 82', arm: 'wave' },
      proud: { eyesFill: open, mouthFill: 'M56 80Q70 98 84 80Z', tongue: 'M64 88q6 5 12 0q-6-3-12 0z', arm: 'cheer' },
      cool: { glasses: 'M42 56h22a3 3 0 0 1 3 3v4a10 10 0 0 1-10 10h-6a10 10 0 0 1-10-10v-4a3 3 0 0 1 3-3z M74 56h22a3 3 0 0 1 3 3v4a10 10 0 0 1-10 10h-6a10 10 0 0 1-10-10v-4a3 3 0 0 1 3-3z M66 60h9', glint: 'M48 61l5-4 M80 61l5-4', mouthFill: 'M56 82Q70 98 84 82Z', arm: 'cheer' },
      flat: { eyesFill: open, mouth: 'M60 88H80', brows: 'M48 54h12 M80 54h12', arm: 'down' },
      worried: { eyesFill: big, brows: 'M46 56l12-6 M94 56l-12-6', mouth: 'M60 90Q70 81 80 90', sweat: 'M104 34c5 7 5 12 0 14-5-2-5-7 0-14z', arm: 'up' },
      shocked: { eyesFill: big, brows: 'M48 48q6-6 12 0 M80 48q6-6 12 0', mouthFill: eye(70, 88, 6.5), arm: 'up' },
      sleepy: { eyesLine: 'M50 68q6 4 12 0 M78 68q6 4 12 0', mouth: 'M65 88q5 3 10 0', arm: 'down' },
      wink: { eyesFill: eye(56, 66, 5), eyesLine: 'M78 67q6-5 12 0', mouth: 'M58 82Q70 94 82 82', arm: 'wave' }
    };
    const m = M[mood] || M.happy;
    const a = A[m.arm] || A.down;
    const s = {}; ['sparkles', 'shield', 'puddle', 'cloud', 'drawer', 'lock', 'dice', 'zzz', 'confetti'].forEach((k) => { s[k] = scenes.indexOf(k) >= 0; });
    return {
      w: size + 'px', h: Math.round(size * 158 / 184) + 'px',
      role: p.label ? 'img' : 'presentation', label: p.label || '', hidden: p.label ? 'false' : 'true',
      still: p.still ? 'lo-still' : '',
      eyesFill: m.eyesFill || 'M0 0', eyesLine: m.eyesLine || 'M0 0', brows: m.brows || 'M0 0', glasses: m.glasses || 'M0 0', glint: m.glint || 'M0 0',
      mouth: m.mouth || 'M0 0', mouthFill: m.mouthFill || 'M0 0', tongue: m.tongue || 'M0 0', sweat: m.sweat || 'M0 0',
      arm: a[0], hx: String(a[1]), hy: String(a[2]), armCls: a[3], s: s
    };
  }
}
