// Passlore — content pages (How it works, Blog, Article, Privacy/Terms, 404) behaviour and copy, extracted from the prototype component.
class Component extends DCLogic {
  icons() {
    if (this._I) return this._I;
    const ring = 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z';
    const dot = (x, y, r) => 'M' + (x - r) + ' ' + y + 'a' + r + ' ' + r + ' 0 1 0 ' + (2 * r) + ' 0a' + r + ' ' + r + ' 0 1 0 ' + (-2 * r) + ' 0';
    this._I = {
      Check: 'M5 12.5l4.5 4.5L19 7.5', X: 'M6 6l12 12 M18 6L6 18', List: 'M4 7h16 M4 12h16 M4 17h16',
      Copy: 'M9 9h11v11H9z M15 9V4H4v11h5', Regen: 'M19 4v5h-5 M5 20v-5h5 M18.6 9A7 7 0 0 0 5.4 8.5 M5.4 15a7 7 0 0 0 13.2.5',
      Link: 'M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1 M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1',
      Export: 'M12 3v12 M8 7l4-4 4 4 M5 11v8a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-8',
      Info: ring + ' M12 11v6 M12 7.5v.1', Warning: 'M12 4L2.8 19.5a.6.6 0 0 0 .5.9h17.4a.6.6 0 0 0 .5-.9z M12 10v4 M12 17.2v.1',
      CheckCircle: ring + ' M8 12.5l3 3 5-6', XCircle: ring + ' M9 9l6 6 M15 9l-6 6',
      ShieldCheck: 'M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6z M9 12l2 2 4-4.5', ShieldWarning: 'M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6z M12 8v5 M12 16v.1',
      Lock: 'M5 11h14v10H5z M8 11V7a4 4 0 0 1 8 0v4', Search: 'M10.5 17a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13z M15.5 15.5L20 20',
      Chart: 'M4 20V10 M10 20V4 M16 20v-7 M3 20h18', Bug: 'M8 8a4 4 0 0 1 8 0v6a4 4 0 0 1-8 0z M12 10v8 M4 12h4 M16 12h4 M5 7l3 2 M19 7l-3 2 M5 18l3-2 M19 18l-3-2',
      Eye: 'M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z', File: 'M6 3h8l4 4v14H6z M14 3v4h4', Repeat: 'M17 2l3 3-3 3 M4 11V9a4 4 0 0 1 4-4h12 M7 22l-3-3 3-3 M20 13v2a4 4 0 0 1-4 4H4',
      Drawer: 'M3 13l3-8h12l3 8 M3 13v6h18v-6 M3 13h5l1 2h6l1-2h5',
      Lightning: 'M13 3L5 13h6l-1 8 8-10h-6z', Vault: 'M4 5h16v14H4z M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M12 9V7.5 M15 12h1.5 M7 19v2 M17 19v2',
      Form: 'M9 3h6v4H9z M15 5h3v16H6V5h3 M9 13.5l2 2 4-4.5', Wifi: 'M2.5 9a14 14 0 0 1 19 0 M5.5 12.5a9.5 9.5 0 0 1 13 0 M8.5 16a5 5 0 0 1 7 0 M12 19.5v.1',
      Tv: 'M3 6h18v12H3z M8 21h8 M9 2l3 3 3-3', Key: 'M8 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M12 12h9 M18 12v3 M15 12v2',
      Dots: [6, 12, 18].map((y) => [6, 12, 18].map((x) => dot(x, y, 1.5)).join(' ')).join(' '),
      Stack: 'M4 7l8-4 8 4-8 4z M4 12l8 4 8-4 M4 17l8 4 8-4', Sliders: 'M4 6h9 M17 6h3 M4 12h3 M11 12h9 M4 18h11 M19 18h1 M15 4v4 M9 10v4 M17 16v4',
      Book: 'M5 4h12a2 2 0 0 1 2 2v14H7a2 2 0 0 1-2-2z M5 18a2 2 0 0 1 2-2h12 M9 8h6',
      Monitor: 'M3 5h18v11H3z M8 20h8 M12 16v4',
      Sun: 'M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M12 2v2 M12 20v2 M4.9 4.9l1.4 1.4 M17.7 17.7l1.4 1.4 M2 12h2 M20 12h2 M4.9 19.1l1.4-1.4 M17.7 6.3l1.4-1.4',
      Moon: 'M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z',
      CircleHalf: ring + ' M12 3v18 M12 7h6.3 M12 11h8.9 M12 15h8.4 M12 19h4.6'
    };
    return this._I;
  }

  recipes() {
    const I = this.icons();
    return [
      ['quick', 'Just one', 'Strong, random, ready now', I.Lightning], ['manager', 'Password manager', 'You’ll never type it', I.Vault],
      ['wifi', 'Wi-Fi', 'Read it out, or scan a QR', I.Wifi], ['pin', 'PIN', 'Phone, card, door', I.Dots], ['custom', 'Build your own', 'Words, site rules, many', I.Sliders]
    ].map((r) => ({ id: r[0], cls: 'rc r-' + r[0], name: r[1], line: r[2], icon: r[3], href: 'Generator.dc.html#r=' + r[0] }));
  }

  pool() { return 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_=+[]{};:,.<>/?~'; }
  rnd(n) { const lim = Math.floor(4294967296 / n) * n; const b = new Uint32Array(1); for (;;) { crypto.getRandomValues(b); if (b[0] < lim) return b[0] % n; } }
  pick(p, n) { let o = ''; for (let i = 0; i < n; i++) o += p[this.rnd(p.length)]; return o; }
  fallbackWords() { return 'acorn amber anchor apron arcade attic badge bamboo banjo barley basin beacon bicycle biscuit blanket bonfire bottle breeze bucket cabin cactus candle canyon carpet cedar chalk cherry chimney cider cobalt comet copper cotton crayon cricket cymbal daisy denim dolphin donkey dragon drizzle eagle ember engine fabric falcon feather fennel fern fiddle forest fossil garnet ginger glacier goblet granite gravel harbor hazel helmet hickory honey island ivory jacket jasmine jigsaw kettle kitten ladder lagoon lantern lemon lilac lizard locket magnet mango maple marble meadow mitten molar monsoon mosaic nectar nickel noodle oasis olive orbit orchid otter oyster paddle pebble pepper pilot pocket quarry quiver radish raven ribbon river rocket saddle salmon satin shovel silver sketch sparrow spinach spruce summit tablet teapot thistle timber toffee tulip turnip velvet violet walnut willow window wombat yarn zebra zipper'.split(' '); }

  S() {
    const p = this.props.page || 'about';
    const base = { theme: this.props.theme || 'system', page: p === 'terms' ? 'privacy' : p, legal: p === 'terms' ? 'terms' : 'privacy', themeMenu: false, menu: false, cat: 'All', active: '', toast: '', announce: '', fresh: '', freshCopied: false, consent: 'unset', draw: null, words: null, artW: 6, artC: 12, artN: 0 };
    return Object.assign(base, this.state || {});
  }

  componentDidMount() {
    this.setState({ fresh: this.pick(this.pool(), 16), draw: this.drawNext('') });
    try { fetch('/_blob/e9b9cca83c322f25512aa66d5ed362e1').then((r) => r.json()).then((w) => { if (Array.isArray(w) && w.length > 1000) { this._art = null; this.setState({ words: w.filter((x) => x !== 'undefined') }); } }).catch(() => {}); } catch (e) {}
    this._onScroll = () => {
      const els = Array.prototype.slice.call(document.querySelectorAll('[data-toc]'));
      let cur = '';
      for (let i = 0; i < els.length; i++) if (els[i].getBoundingClientRect().top < 160) cur = els[i].getAttribute('data-toc');
      if (cur !== this.S().active) this.setState({ active: cur });
    };
    window.addEventListener('scroll', this._onScroll, { passive: true });
  }

  componentWillUnmount() { window.removeEventListener('scroll', this._onScroll); clearTimeout(this._t); clearTimeout(this._ft); }

  drawNext(prev) {
    const lim = Math.floor(4294967296 / 89) * 89;
    const b = new Uint32Array(1); crypto.getRandomValues(b);
    const u = b[0], ok = u < lim, idx = u % 89;
    const start = prev.length >= 16 ? '' : prev;
    return { u: u, ok: ok, idx: idx, cut: ok ? start + this.pool()[idx] : start };
  }

  tier(bits) {
    const I = this.icons();
    const T = [['Very weak', 'var(--st-danger)', I.XCircle], ['Weak', 'var(--st-danger)', I.ShieldWarning], ['Fair', 'var(--st-warning)', I.Warning], ['Strong', 'var(--st-success)', I.ShieldCheck], ['Very strong', 'var(--st-success)', I.ShieldCheck]];
    const t = bits < 28 ? T[0] : bits < 50 ? T[1] : bits < 70 ? T[2] : bits < 100 ? T[3] : T[4];
    return { name: t[0], tone: t[1], icon: t[2] };
  }

  crack(bits) {
    const lg = (bits - 1) * Math.log10(2) - 11;
    const s = Math.pow(10, lg);
    const r = (x) => (x < 10 ? x.toFixed(1).replace('.0', '') : String(Math.round(x)));
    const y = s / 31557600;
    let text;
    if (lg < 0) text = 'less than a second';
    else if (s < 60) text = 'about ' + r(s) + ' seconds';
    else if (s < 3600) text = 'about ' + r(s / 60) + ' minutes';
    else if (s < 86400) text = 'about ' + r(s / 3600) + ' hours';
    else if (y < 1) text = 'about ' + r(s / 86400) + ' days';
    else if (y < 1000) text = 'about ' + r(y) + ' years';
    else if (y < 1e15) { const big = [[1e12, 'trillion'], [1e9, 'billion'], [1e6, 'million'], [1e3, 'thousand']]; for (let i = 0; i < big.length; i++) if (y >= big[i][0]) { text = 'about ' + r(y / big[i][0]) + ' ' + big[i][1] + ' years'; break; } }
    else { const sup = '⁰¹²³⁴⁵⁶⁷⁸⁹'; text = 'about 10' + String(Math.floor(Math.log10(y))).split('').map((d) => sup[+d]).join('') + ' years'; }
    const U = 13.8e9;
    let cmp = '';
    if (y >= U) { const k = y / U; cmp = k < 1000 ? '— ≈ ' + Math.round(k).toLocaleString('en-GB') + '× the age of the universe' : '— far longer than the universe has existed'; }
    else if (y >= 4.54e9) cmp = '— longer than the Earth has existed';
    else if (y >= 3e5) cmp = '— longer than humans have existed';
    else if (y >= 5000) cmp = '— longer than all of recorded history';
    else if (y >= 80) cmp = '— longer than a lifetime';
    else if (y >= 1) cmp = '— within a lifetime';
    else cmp = '— a determined attacker gets there';
    return { lg: lg, text: text, cmp: cmp, pos: Math.max(0, Math.min(100, ((lg + 2) / 32) * 100)).toFixed(1) + '%' };
  }

  toast(t) { this.setState({ toast: t, announce: t }); clearTimeout(this._t); this._t = setTimeout(() => this.setState({ toast: '' }), 5000); }

  clip(text, done) {
    try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(text).then(() => done(true), () => done(false)); return; } } catch (e) {}
    done(false);
  }

  renderVals() {
    const s = this.S();
    const I = this.icons();
    const fmt = (n) => Math.round(n).toLocaleString('en-GB');
    const themeDefs = [['system', 'System', I.Monitor], ['light', 'Light', I.Sun], ['dark', 'Dark', I.Moon], ['sepia', 'Sepia', I.Book], ['hc', 'High contrast', I.CircleHalf]];
    const thI = Math.max(0, themeDefs.findIndex((t) => t[0] === s.theme));
    const tocA = [['random', 'Where randomness comes from'], ['fair', 'Every character equally likely'], ['strength', 'What makes it strong'], ['breach', 'What the breach check sends'], ['limits', 'What it can’t promise'], ['open', 'Open source']];
    const tocB = [['what', 'What each one is'], ['strength', 'How strong each is'], ['phrase', 'When a passphrase wins'], ['random', 'When a random password wins'], ['faq', 'Questions']];
    const toc = (s.page === 'article' ? tocB : tocA).map((t, i) => ({ href: '#' + t[0], label: t[1], cur: (s.active ? s.active === t[0] : i === 0) ? 'true' : 'false' }));
    const deck = this.recipes();
    const byId = (id) => deck.find((r) => r.id === id);
    const marks = [['a second', 0], ['an hour', 3.556], ['a year', 7.499], ['a lifetime', 9.402], ['recorded history', 11.198], ['age of the universe', 17.639]].map((k, i) => ({ label: k[0], pos: Math.max(0, Math.min(100, ((k[1] + 2) / 32) * 100)).toFixed(1) + '%', top: i % 2 ? '20px' : '0px' }));

    // ---- cut one character
    const P = this.pool();
    const d = s.draw || { u: 0, ok: true, idx: 0, cut: '' };
    const draw = {
      u: fmt(d.u), idx: String(d.idx), ch: P[d.idx], cut: d.cut, rest: '·'.repeat(Math.max(0, 16 - d.cut.length)), count: String(d.cut.length),
      okLine: d.ok ? 'Below 4,294,967,251, the largest multiple of 89' : 'In the top 45 values — thrown away, draw again',
      okWord: d.ok ? 'kept' : 'redrawn',
      btn: d.cut.length >= 16 ? 'Start a new one' : 'Draw the next character',
      pool: P.split('').map((ch, i) => ({ ch: ch, on: i === d.idx ? 'true' : 'false' }))
    };

    // ---- article compare
    const W = s.words || this.fallbackWords();
    const key = s.artW + '|' + s.artC + '|' + s.artN + '|' + (s.words ? 'w' : 'f');
    if (!this._art || this._art.key !== key) {
      const prev = this._art || {};
      const ws = prev.ws && prev.wn === s.artN && prev.wl === (s.words ? 'w' : 'f') ? prev.ws.slice(0, s.artW) : [];
      while (ws.length < s.artW) ws.push(W[this.rnd(W.length)]);
      const cs = prev.cs && prev.wn === s.artN ? prev.cs.slice(0, s.artC) : '';
      this._art = { key: key, ws: ws, cs: cs + this.pick(P, Math.max(0, s.artC - cs.length)), wn: s.artN, wl: s.words ? 'w' : 'f' };
    }
    const listN = W.length;
    const wBits = s.artW * Math.log2(listN), chBits = s.artC * Math.log2(89);
    const wT = this.tier(wBits), cT2 = this.tier(chBits), wC = this.crack(wBits), cC2 = this.crack(chBits);
    const wPhrase = this._art.ws.join(' ');
    const diff = wBits - chBits;
    const art = {
      listN: W.length.toLocaleString('en-GB'), w: String(s.artW), c: String(s.artC), wSample: wPhrase, cSample: this._art.cs,
      wBits: wBits.toFixed(1), cBits: chBits.toFixed(1), wTier: wT.name, cTier: cT2.name, wLen: String(wPhrase.length),
      wPos: wC.pos, cPos: cC2.pos,
      aria: 'Time-to-guess scale. Words: ' + wT.name + ', ' + wC.text + '. Characters: ' + cT2.name + ', ' + cC2.text + '.',
      verdict: Math.abs(diff) < 3 ? 'About the same strength — pick by who types it.' : diff > 0 ? 'The words are stronger here by ' + diff.toFixed(0) + ' bits.' : 'The characters are stronger here by ' + (-diff).toFixed(0) + ' bits.',
      onW: (ev) => this.setState({ artW: Math.max(3, Math.min(10, parseInt(ev.target.value, 10) || 6)) }),
      onC: (ev) => this.setState({ artC: Math.max(6, Math.min(32, parseInt(ev.target.value, 10) || 12)) }),
      reroll: () => { this._art = null; this.setState({ artN: s.artN + 1, announce: 'New examples cut.' }); }
    };
    if (!s.words) art.verdict += ' (Sample words from a short built-in list until the full list loads.)';

    // ---- blog
    const posts = [
      { cat: 'Basics', recipe: 'Just one', rid: 'quick', title: 'How to make a strong password (and why length wins)', excerpt: 'Why a long random password beats a clever short one, and how many characters is enough.', motif: 'M28 44h40v14H28z M28 66h88v14H28z M28 88h150v14H28z M28 110h230v14H28z' },
      { cat: 'Explainers', recipe: 'Build your own', rid: 'custom', title: 'Entropy, explained without the headache', excerpt: 'What “bits” means, where the number comes from, and why patterns cost more than they look.', motif: 'M40 30h22v22H40z M72 30h22v22H72z M104 30h22v22h-22z M136 30h22v22h-22z M40 62h22v22H40z M72 62h22v22H72z M104 62h22v22h-22z M40 94h22v22H40z M72 94h22v22H72z M40 126h22v22H40z' },
      { cat: 'Comparisons', recipe: 'Password manager', rid: 'manager', title: 'Password manager vs generator: what each one does', excerpt: 'A generator makes the password; a manager keeps it. You almost certainly want both.', motif: 'M184 40h100v84H184z M206 70h56v24h-56z M60 40h40v90H60z M100 40a30 30 0 0 1 0 60z' },
      { cat: 'Standards', recipe: 'Site rules', rid: 'form', title: 'What NIST’s password guidelines actually say', excerpt: 'Length over composition rules, no forced resets, check against breached lists — in plain words.', motif: 'M30 54h260v14H30z M30 78h200v14H30z M30 102h230v14H30z M250 20l30 30-30 30-30-30z' },
      { cat: 'Basics', recipe: 'Wi-Fi', rid: 'wifi', title: 'A Wi-Fi password your guests can actually type', excerpt: 'Random words, a QR code on the fridge, and why “Password123” on the router is still everywhere.', motif: 'M60 120a100 100 0 0 1 200 0h-24a76 76 0 0 0-152 0z M104 120a56 56 0 0 1 112 0h-24a32 32 0 0 0-64 0z M150 120h20v20h-20z' },
      { cat: 'Explainers', recipe: 'Site rules', rid: 'form', title: 'Why password rules make you less safe — and how to fit them anyway', excerpt: '“At least one symbol, but not that one.” What composition rules cost, and how to beat them.', motif: 'M40 40h60v84H40z M120 40h60v84h-60z M200 40h60v84h-60z M52 82l12 12 24-26 M226 70l20 28 M246 70l-20 28' }
    ].map((p) => Object.assign(p, { cls: 'r-' + p.rid }));
    const cats = ['All', 'Basics', 'Explainers', 'Comparisons', 'Standards'];
    const shown = posts.filter((p) => s.cat === 'All' || p.cat === s.cat);
    const featured = s.cat === 'All' || s.cat === 'Comparisons';

    // ---- legal
    const privacy = [
      { id: 'summary', h: 'The short version', ps: ['Passlore generates passwords in your browser. No generated password, and no password you check, is ever sent to [COMPANY NAME] or stored on a server we run.'] },
      { id: 'device', h: 'What stays on your device', ps: ['Generated passwords, your settings and the drawer (this tab’s history). The drawer is plain text in this tab’s session storage, holds the last 20 items and is erased when the tab closes. Your theme and analytics choice are kept in local storage so they persist between visits. The clipboard is cleared after 60 seconds only if you turn that on.'] },
      { id: 'breach', h: 'The optional breach check', ps: ['Only when you press it, your browser computes a SHA-1 hash of the password and sends the first 5 of its 40 characters to Have I Been Pwned (a third-party service). The match happens on your device. Have I Been Pwned’s own privacy terms apply to that request.'] },
      { id: 'analytics', h: 'Analytics, only with your consent', ps: ['If you choose “Allow”, [ANALYTICS PROVIDER] counts page visits and which recipe was used: [DATA COLLECTED]. Passwords, site rules you paste and network names are never included. If you decline, nothing is collected and the site works exactly the same.'] },
      { id: 'hosting', h: 'Hosting', ps: ['The site is served by [HOSTING PROVIDER], which may process standard request data such as IP address and browser type to deliver pages and prevent abuse: [RETENTION PERIOD].'] },
      { id: 'contact', h: 'Your rights and contact', ps: ['You can change your analytics choice below at any time. For questions or requests, contact [CONTACT EMAIL].'] }
    ];
    const terms = [
      { id: 'use', h: 'Using Passlore', ps: ['Passlore is free to use for any lawful purpose. There is no account and nothing to buy.'] },
      { id: 'warranty', h: 'No warranty', ps: ['Passlore is provided “as is” under the MIT licence, without warranty of any kind. [COMPANY NAME] is not liable for any loss arising from its use.'] },
      { id: 'estimates', h: 'Estimates are not guarantees', ps: ['Strength and time-to-guess figures are estimates based on stated assumptions. They are not a certification of security. The rules reader matches common phrasing; always check the result against the site.'] },
      { id: 'yours', h: 'Your responsibility', ps: ['Store generated passwords securely, ideally in a password manager. Downloaded files and Wi-Fi QR images are unencrypted; you are responsible for deleting them.'] },
      { id: 'third', h: 'Third-party services', ps: ['The optional breach check uses Have I Been Pwned, which is operated independently and has its own terms.'] },
      { id: 'changes', h: 'Changes and contact', ps: ['We may update these terms; the date above shows the latest version. Contact: [CONTACT EMAIL].'] }
    ];
    const legal = s.legal === 'terms' ? terms : privacy;
    const curOf = (pg) => (s.page === pg || (pg === 'blog' && s.page === 'article') ? 'page' : 'false');

    return {
      I: I, theme: s.theme, announce: s.announce, marks: marks, deck: deck,
      curAbout: curOf('about'), curBlog: curOf('blog'),
      themeMenu: s.themeMenu, themeMenuExp: s.themeMenu ? 'true' : 'false', toggleThemeMenu: () => this.setState({ themeMenu: !s.themeMenu }),
      themeIcon: themeDefs[thI][2], themeName: themeDefs[thI][1], themeAria: 'Theme: ' + themeDefs[thI][1],
      themes: themeDefs.map((t) => ({ name: t[1], icon: t[2], on: t[0] === s.theme, checked: t[0] === s.theme ? 'true' : 'false', pick: () => this.setState({ theme: t[0], themeMenu: false }) })),
      menu: s.menu, menuExp: s.menu ? 'true' : 'false', menuAria: s.menu ? 'Close menu' : 'Open menu', menuIcon: s.menu ? I.X : I.List, toggleMenu: () => this.setState({ menu: !s.menu }),
      isAbout: s.page === 'about', isBlog: s.page === 'blog', isArticle: s.page === 'article', isLegal: s.page === 'privacy', isNotFound: s.page === '404',
      footGap: s.page === 'about' || s.page === '404' ? '0px' : '96px',
      toc: toc,
      draw: draw,
      drawOne: () => { const n = this.drawNext(d.cut); this.setState({ draw: n, announce: 'Number ' + fmt(n.u) + ', ' + (n.ok ? 'kept' : 'redrawn') + ', character ' + P[n.idx] }); },
      drawAll: () => { let cur = d.cut.length >= 16 ? '' : d.cut; let last = null; while (cur.length < 16) { last = this.drawNext(cur); cur = last.cut; } this.setState({ draw: last, announce: 'Cut the rest: ' + cur.length + ' characters.' }); },
      limits: [
        { icon: I.Bug, h: 'Malware wins.', p: 'Nothing in a web page can protect a password from malware, a malicious extension or someone watching your screen.' },
        { icon: I.Drawer, h: 'The drawer isn’t a vault.', p: 'It’s plain text in this tab until you close it. Save what you keep in a password manager.' },
        { icon: I.Search, h: '“Not found” isn’t “safe”.', p: 'It only covers breaches in Have I Been Pwned’s dataset.' },
        { icon: I.Repeat, h: 'Reuse undoes everything.', p: 'Every estimate assumes the password is used in one place only.' }
      ],
      cats: cats.map((c) => ({ name: c, sel: c === s.cat ? 'true' : 'false', pick: () => this.setState({ cat: c, announce: c === 'All' ? 'Showing all articles' : 'Showing ' + c }) })),
      cat: s.cat, catAria: s.cat === 'All' ? 'All articles' : 'Articles in ' + s.cat,
      posts: shown, hasFeatured: featured, noPosts: !shown.length && !featured, allCats: () => this.setState({ cat: 'All', announce: 'Showing all articles' }),
      art: art,
      copyLink: () => this.clip('https://passlore.com/blog/passphrase-vs-password', (ok) => this.toast(ok ? 'Link copied.' : 'Couldn’t reach the clipboard — copy the address from your browser.')),
      shareArticle: () => { if (navigator.share) navigator.share({ title: 'Passphrase vs password', url: 'https://passlore.com/blog/passphrase-vs-password' }).catch(() => {}); else this.clip('https://passlore.com/blog/passphrase-vs-password', (ok) => this.toast(ok ? 'Sharing isn’t available here, so the link was copied.' : 'Sharing isn’t available here.')); },
      isPrivacy: s.legal === 'privacy', isTerms: s.legal === 'terms', isPrivacyStr: s.legal === 'privacy' ? 'true' : 'false', isTermsStr: s.legal === 'terms' ? 'true' : 'false',
      showPrivacy: () => this.setState({ legal: 'privacy' }), showTerms: () => this.setState({ legal: 'terms' }),
      legalTitle: s.legal === 'terms' ? 'Terms of use' : 'Privacy',
      legalLede: s.legal === 'terms' ? 'Short, plain terms for a free, open-source tool.' : 'Passlore is built so there’s almost nothing to tell you: your passwords never reach us.',
      legalToc: legal.map((x) => ({ href: '#' + x.id, label: x.h })),
      legalSections: legal,
      consentShort: s.consent === 'yes' ? 'You allowed it: page visits and recipe used, nothing else.' : s.consent === 'no' ? 'You said no. Nothing is collected.' : 'Nothing until you choose. You haven’t yet.',
      consentLine: s.consent === 'yes' ? 'You allowed analytics on this device.' : s.consent === 'no' ? 'You declined analytics on this device. Nothing is collected.' : 'You haven’t chosen yet, so nothing is collected.',
      consentYesP: s.consent === 'yes' ? 'true' : 'false', consentNoP: s.consent === 'no' ? 'true' : 'false',
      consentYes: () => { this.setState({ consent: 'yes' }); this.toast('Analytics allowed. You can change this any time.'); },
      consentNo: () => { this.setState({ consent: 'no' }); this.toast('Analytics off. Nothing is collected.'); },
      fresh: s.fresh || '················', freshAria: 'Password: ' + (s.fresh || '').split('').join(' '),
      freshCopied: s.freshCopied, freshDone: s.freshCopied ? 'true' : 'false',
      freshIcon: s.freshCopied ? I.Check : I.Copy, freshLabel: s.freshCopied ? 'Copied' : 'Copy',
      copyFresh: () => this.clip(s.fresh, (ok) => { if (ok) { this.setState({ freshCopied: true, announce: 'Password copied.' }); clearTimeout(this._ft); this._ft = setTimeout(() => this.setState({ freshCopied: false }), 2400); } else this.toast('Couldn’t reach the clipboard. Select the password and copy it.'); }),
      newFresh: () => this.setState({ fresh: this.pick(P, 16), freshCopied: false, announce: 'New password cut.' }),
      hasToast: !!s.toast, toastText: s.toast, dismissToast: () => this.setState({ toast: '' })
    };
  }
}
