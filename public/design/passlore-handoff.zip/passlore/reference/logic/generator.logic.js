// Passlore — Generator behaviour, extracted from the prototype component.
// DCLogic is the prototype runtime base class: this.props, this.state, this.setState(), componentDidMount(), renderVals() returns the values the template binds.
// Port the pure functions (rnd, sets, gen*, metrics, tier, crack, parseRules, form*, phrase, hashOf, cardSvg, cardPng) as-is; replace renderVals with React state + JSX.
class Component extends DCLogic {
  icons() {
    if (this._I) return this._I;
    const dot = (x, y, r) => 'M' + (x - r) + ' ' + y + 'a' + r + ' ' + r + ' 0 1 0 ' + (2 * r) + ' 0a' + r + ' ' + r + ' 0 1 0 ' + (-2 * r) + ' 0';
    const ring = 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z';
    this._I = {
      Lightning: 'M13 3L5 13h6l-1 8 8-10h-6z',
      Vault: 'M4 5h16v14H4z M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M12 9V7.5 M15 12h1.5 M7 19v2 M17 19v2',
      Form: 'M9 3h6v4H9z M15 5h3v16H6V5h3 M9 13.5l2 2 4-4.5',
      Wifi: 'M2.5 9a14 14 0 0 1 19 0 M5.5 12.5a9.5 9.5 0 0 1 13 0 M8.5 16a5 5 0 0 1 7 0 M12 19.5v.1',
      Tv: 'M3 6h18v12H3z M8 21h8 M9 2l3 3 3-3',
      Key: 'M8 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M12 12h9 M18 12v3 M15 12v2',
      Dots: [6, 12, 18].map((y) => [6, 12, 18].map((x) => dot(x, y, 1.5)).join(' ')).join(' '),
      Stack: 'M4 7l8-4 8 4-8 4z M4 12l8 4 8-4 M4 17l8 4 8-4',
      Sliders: 'M4 6h9 M17 6h3 M4 12h3 M11 12h9 M4 18h11 M19 18h1 M15 4v4 M9 10v4 M17 16v4',
      TextAa: 'M3 18l4.5-12L12 18 M4.7 14h5.6 M16.5 17a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z M19 12v6',
      Speaker: 'M4 9h4l5-4v14l-5-4H4z M16.5 9a4 4 0 0 1 0 6 M19 6.5a8 8 0 0 1 0 11',
      Expand: 'M4 9V4h5 M20 9V4h-5 M4 15v5h5 M20 15v5h-5',
      Copy: 'M9 9h11v11H9z M15 9V4H4v11h5',
      Check: 'M5 12.5l4.5 4.5L19 7.5',
      Export: 'M12 3v12 M8 7l4-4 4 4 M5 11v8a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-8',
      Download: 'M12 4v11 M8 11l4 4 4-4 M5 20h14',
      Eye: 'M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
      EyeSlash: 'M4 4l16 16 M10 5.2A10 10 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3 3.9 M6.6 6.6C3.9 8.3 2 12 2 12s3.5 7 10 7a9.6 9.6 0 0 0 5.4-1.6 M9.9 9.9a3 3 0 0 0 4.2 4.2',
      Regen: 'M19 4v5h-5 M5 20v-5h5 M18.6 9A7 7 0 0 0 5.4 8.5 M5.4 15a7 7 0 0 0 13.2.5',
      Plus: 'M12 5v14 M5 12h14', X: 'M6 6l12 12 M18 6L6 18', Arrow: 'M5 12h14 M13 6l6 6-6 6',
      ShieldCheck: 'M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6z M9 12l2 2 4-4.5',
      ShieldWarning: 'M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6z M12 8v5 M12 16v.1',
      CheckCircle: ring + ' M8 12.5l3 3 5-6',
      Warning: 'M12 4L2.8 19.5a.6.6 0 0 0 .5.9h17.4a.6.6 0 0 0 .5-.9z M12 10v4 M12 17.2v.1',
      XCircle: ring + ' M9 9l6 6 M15 9l-6 6',
      Question: ring + ' M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.5v.5 M12 17v.1',
      Info: ring + ' M12 11v6 M12 7.5v.1',
      Search: 'M10.5 17a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13z M15.5 15.5L20 20',
      WifiSlash: 'M4 4l16 16 M8.5 16.5a5 5 0 0 1 5.5-1 M5 12.5a10 10 0 0 1 4.3-2.4 M19 12.5a10 10 0 0 0-3-2 M2 9a14 14 0 0 1 4.2-2.7 M22 9a14 14 0 0 0-11-3.9 M12 20v.1',
      Lock: 'M5 11h14v10H5z M8 11V7a4 4 0 0 1 8 0v4',
      Notch: 'M12 3a9 9 0 1 0 9 9',
      Prohibit: ring + ' M5.6 5.6l12.8 12.8',
      List: 'M4 7h16 M4 12h16 M4 17h16',
      CaretDown: 'M6 9l6 6 6-6', CaretUp: 'M6 15l6-6 6 6',
      Drawer: 'M3 13l3-8h12l3 8 M3 13v6h18v-6 M3 13h5l1 2h6l1-2h5',
      Clipboard: 'M9 3h6v4H9z M15 5h3v16H6V5h3',
      Monitor: 'M3 5h18v11H3z M8 20h8 M12 16v4',
      Sun: 'M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M12 2v2 M12 20v2 M4.9 4.9l1.4 1.4 M17.7 17.7l1.4 1.4 M2 12h2 M20 12h2 M4.9 19.1l1.4-1.4 M17.7 6.3l1.4-1.4',
      Moon: 'M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z',
      Book: 'M5 4h12a2 2 0 0 1 2 2v14H7a2 2 0 0 1-2-2z M5 18a2 2 0 0 1 2-2h12 M9 8h6',
      CircleHalf: ring + ' M12 3v18 M12 7h6.3 M12 11h8.9 M12 15h8.4 M12 19h4.6',
      Cpu: 'M7 7h10v10H7z M10 3v4 M14 3v4 M10 17v4 M14 17v4 M3 10h4 M3 14h4 M17 10h4 M17 14h4'
    };
    return this._I;
  }

  recipeDefs() {
    const I = this.icons();
    return [
      { id: 'quick', deck: true, cls: 'r-quick', name: 'Just one', line: 'Strong, random, ready now', icon: I.Lightning, title: 'Just one, ready to paste', why: 'Random characters from all four types. Strong for nearly any account — let your password manager remember it.' },
      { id: 'manager', deck: true, cls: 'r-manager', name: 'Password manager', line: 'You’ll never type it', icon: I.Vault, title: 'For your password manager', why: 'Your manager fills it in, so length costs nothing. If a site rejects something this long, switch to Picky form.' },
      { id: 'form', cls: 'r-form', name: 'Site rules', line: 'Paste the site’s rules', icon: I.Form, title: 'Fit a site’s rules', why: 'Paste the site’s rules. Passlore reads them on this device, then cuts the longest password they allow, using every character type they accept.' },
      { id: 'wifi', deck: true, cls: 'r-wifi', name: 'Wi-Fi', line: 'Read it out, or scan a QR', icon: I.Wifi, title: 'For your Wi-Fi', why: 'Random words are easy to read out and type on a phone, and stay well inside Wi-Fi’s 8–63 character limit. Guests can scan the QR instead of typing.' },
      { id: 'tv', cls: 'r-tv', name: 'TV & consoles', line: 'Typing with a remote', icon: I.Tv, title: 'For a TV or games console', why: 'Lowercase words with spaces: every on-screen keyboard has them on its first page, so nobody hunts for symbols with a remote.' },
      { id: 'master', cls: 'r-master', name: 'Master password', line: 'The one you remember', icon: I.Key, title: 'Your master password', why: 'The password that unlocks all the others has to live in your head. Seven random words are strong and learnable — practise below until it sticks.' },
      { id: 'pin', deck: true, cls: 'r-pin', name: 'PIN', line: 'Phone, card, door', icon: I.Dots, title: 'A PIN', why: 'Digits only. A PIN is safe only where guesses are limited — the device locks after a few wrong tries. Obvious PINs are skipped.' },
      { id: 'bulk', cls: 'r-bulk', name: 'Many at once', line: 'For a team or test accounts', icon: I.Stack, title: 'Many at once', why: 'Up to 500 from one recipe, each cut independently. Export as text, CSV or JSON for onboarding or test accounts.' },
      { id: 'custom', deck: true, cls: 'r-custom', name: 'Build your own', line: 'Words, site rules, many', icon: I.Sliders, title: 'Build your own', why: 'Pick characters or words, fit a site’s password rules, or make many at once.' }
    ];
  }

  words() {
    if (this._W) return this._W;
    const raw = 'able acid aged also arch army atom aunt away axis baby back bake ball band bank barn base bath beam bean bear bell belt bench berry bike bird blue boat body bold bolt bone book boot bowl brave bread brick bridge brook brush cabin cable cake calm camel camp canal candle canoe cape card cargo cart castle cave cedar chair chalk charm chess chief chime cider city clay cliff clock cloud clover coast cocoa comet coral cork corn cotton couch crane creek crisp crow crown cube cup curve daisy dance dawn deer delta desk dial dime dock dome door dove dream drift drum dune eagle earth easel echo elbow elm ember engine fable falcon farm fawn feast fern ferry field fig film finch fire flag flame flint flute foam fog forest fox frame frost fruit gable garden gate gem giant ginger glade globe glove goat gold goose grain grape grass gravel grove guitar gull hall hammer harbor harp hawk hazel heart hedge helm hill hinge hive honey hook horn horse hotel house iris iron island ivory ivy jacket jade jam jar jazz jelly jewel jungle kayak kettle kite kiwi knot ladder lake lamp lane lantern lark lava lawn leaf lemon lens lily lime linen lion lodge loft lotus lunar magnet mango maple marble market marsh mask meadow melon metal mint mirror mist moon moose moss motor mule music nest noble north novel oak oasis ocean olive onion opal orbit orchid otter oval owl paddle palm panda paper parade park parrot pasta peach pearl pebble pedal pencil pepper piano pier pilot pine pixel planet plum pocket poem polar pond poppy porch prism pulse puzzle quail quarry quartz quest quill rabbit radar radio rain ranch raven reef ribbon ridge river road robin rocket roof rope rose ruby saddle sage sail salmon sand satin scarf scout season seed shadow shell shore silk silver sketch sky slate sled slope snow sofa solar sonnet spark spice spoon spring spruce square stable star steam stone storm stream sugar summit swan table tango teapot tent thistle thunder tide tiger timber toast topaz torch tower trail train tree tulip tunnel turtle twig valley vapor velvet violet violin voyage wagon walnut walrus water wave wheat whale willow window winter wolf wood wool yacht yard yarn zebra zenith zinc';
    this._W = Array.from(new Set(raw.split(' ')));
    return this._W;
  }

  W(s) { return (s && s.wordList && s.wordList.length) ? s.wordList : this.words(); }

  rnd(n) {
    const lim = Math.floor(4294967296 / n) * n;
    const buf = new Uint32Array(1);
    for (;;) { crypto.getRandomValues(buf); if (buf[0] < lim) return buf[0] % n; }
  }

  sets() { return { U: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', L: 'abcdefghijklmnopqrstuvwxyz', D: '0123456789', S: '!@#$%^&*()-_=+[]{};:,.<>/?~', SIM: '0Oo1lI|', AMB: '{}[]()/\\\'"`~,;:.<>' }; }

  uniq(str) { return Array.from(new Set(str.split(''))).join(''); }

  pickN(pool, n) { let o = ''; for (let i = 0; i < n; i++) o += pool[this.rnd(pool.length)]; return o; }

  obviousPin(p) {
    if (/^(\d)\1+$/.test(p)) return true;
    const asc = '01234567890123456789', desc = '98765432109876543210';
    if (asc.indexOf(p) >= 0 || desc.indexOf(p) >= 0) return true;
    if (/^(\d\d)\1+$/.test(p) || /^(\d\d\d)\1+$/.test(p)) return true;
    if (p.length === 4 && /^(19|20)\d\d$/.test(p)) return true;
    return ['2580', '0852', '1004', '6969', '1122', '1313', '5683', '0007', '7777', '123123', '112233', '696969', '159753', '147258'].indexOf(p) >= 0;
  }

  parseRules(text) {
    const t = (text || '').toLowerCase().replace(/–|—/g, '-');
    const r = { min: null, max: null, upper: false, lower: false, digit: false, symbol: false, noSymbols: false, syms: null, noSpaces: false, startLetter: false, found: [] };
    let m = t.match(/(\d{1,3})\s*(?:-|to)\s*(\d{1,3})\s*(?:characters|chars|letters|long)?/);
    if (m) { r.min = +m[1]; r.max = +m[2]; r.found.push('len'); }
    m = t.match(/(?:at least|minimum(?: of)?|min\.?)\s*(\d{1,3})/); if (m && r.min == null) { r.min = +m[1]; r.found.push('min'); }
    m = t.match(/(?:at most|maximum(?: of)?|max\.?|no more than|up to)\s*(\d{1,3})/); if (m && r.max == null) { r.max = +m[1]; r.found.push('max'); }
    if (/upper\s?case|capital/.test(t)) r.upper = true;
    if (/lower\s?case/.test(t)) r.lower = true;
    if (/\b(number|digit|numeral)s?\b/.test(t)) r.digit = true;
    if (/no (special|symbol)|only letters and (numbers|digits)|alphanumeric|letters and numbers only/.test(t)) r.noSymbols = true;
    else if (/special|symbol|punctuation/.test(t)) r.symbol = true;
    m = t.match(/\(\s*([^\sa-z0-9()]{2,})\s*\)/) || t.match(/(?:symbols?|special characters?)[^:]{0,30}:\s*([^\sa-z0-9]{2,})/) || t.match(/(?:only|allowed)[^.]{0,30}?([!@#$%^&*_\-+=.?~]{2,})/);
    if (m && !r.noSymbols) r.syms = this.uniq(m[1].replace(/[a-z0-9\s]/g, ''));
    if (/no spaces?|without spaces|cannot contain spaces/.test(t)) r.noSpaces = true;
    if (/(start|begin)s?\s+with\s+a\s+letter/.test(t)) r.startLetter = true;
    return r;
  }

  formRules(s) {
    const f = s.cfg.form;
    const p = this.parseRules(f.text);
    const o = f.ov || {};
    const take = (k, v) => (o[k] !== undefined ? o[k] : v);
    const rules = { min: take('min', p.min), max: take('max', p.max), upper: take('upper', p.upper), lower: take('lower', p.lower), digit: take('digit', p.digit), symbol: take('symbol', p.symbol), noSymbols: take('noSymbols', p.noSymbols), syms: take('syms', p.syms), noSpaces: true, startLetter: take('startLetter', p.startLetter), parsed: p };
    return rules;
  }

  formPool(r) {
    const C = this.sets();
    const sym = r.noSymbols ? '' : (r.syms != null ? r.syms : C.S);
    return { U: C.U, L: C.L, D: C.D, S: sym, all: C.U + C.L + C.D + sym };
  }

  formLen(r) {
    let len = r.max != null ? r.max : Math.max(r.min || 0, 20);
    return Math.max(1, Math.min(128, len));
  }

  formOk(pw, r, P) {
    if (r.upper && !/[A-Z]/.test(pw)) return false;
    if (r.lower && !/[a-z]/.test(pw)) return false;
    if (r.digit && !/[0-9]/.test(pw)) return false;
    if (r.symbol && !pw.split('').some((c) => P.S.indexOf(c) >= 0)) return false;
    if (r.startLetter && !/^[A-Za-z]/.test(pw)) return false;
    return true;
  }

  formConflict(r) {
    const P = this.formPool(r);
    const need = (r.upper ? 1 : 0) + (r.lower ? 1 : 0) + (r.digit ? 1 : 0) + (r.symbol ? 1 : 0);
    if (r.min != null && r.max != null && r.min > r.max) return { title: 'The length rules contradict each other', text: 'Shortest is ' + r.min + ' but longest is ' + r.max + '. Check the numbers you pasted.', fix: 'Use ' + r.max + ' as both', patch: { min: r.max } };
    if (r.symbol && !P.S.length) return { title: 'A symbol is required, but none are allowed', text: 'The rules ask for a symbol and also allow no symbols. One of them is probably a misread — check the site.', fix: 'Drop the symbol requirement', patch: { symbol: false } };
    if (need > this.formLen(r)) return { title: 'Too short for everything it requires', text: 'It must include ' + need + ' kinds of character but can only be ' + this.formLen(r) + ' long.', fix: 'Allow ' + need + ' characters', patch: { max: need } };
    return null;
  }

  genForm(s) {
    const r = this.formRules(s);
    const c = this.formConflict(r);
    if (c) return { password: '', err: 'form', bulk: [] };
    const P = this.formPool(r);
    const L = this.formLen(r);
    for (let i = 0; i < 4000; i++) { const pw = this.pickN(P.all, L); if (this.formOk(pw, r, P)) return { password: pw, err: '', bulk: [] }; }
    return { password: '', err: 'form', bulk: [] };
  }

  quickPool(c) {
    const C = this.sets();
    let p = C.U + C.L + C.D + (c.symbols ? C.S : '');
    if (c.noSimilar) p = p.split('').filter((x) => C.SIM.indexOf(x) < 0).join('');
    return p;
  }

  customPool(c) {
    const C = this.sets();
    const p = (c.upper ? C.U : '') + (c.lower ? C.L : '') + (c.digits ? C.D : '') + (c.symbols ? C.S : '');
    const drop = (c.noSimilar ? C.SIM : '') + (c.exclude || '');
    return this.uniq(p).split('').filter((x) => drop.indexOf(x) < 0).join('');
  }

  phrase(s, n, sep, list) {
    const W = list || this.W(s);
    const w = [];
    for (let i = 0; i < n; i++) w.push(W[this.rnd(W.length)]);
    return w.join(sep);
  }

  gen(s) {
    const c = s.cfg[s.recipe];
    const C = this.sets();
    switch (s.recipe) {
      case 'quick': { const p = this.quickPool(c); return { password: this.pickN(p, c.length), err: '', bulk: [] }; }
      case 'manager': return { password: this.pickN(C.U + C.L + C.D + C.S, c.length), err: '', bulk: [] };
      case 'form': return this.genForm(s);
      case 'wifi': return { password: this.phrase(s, c.words, c.sep), err: '', bulk: [] };
      case 'tv': return { password: this.phrase(s, c.words, ' '), err: '', bulk: [] };
      case 'master': return { password: this.phrase(s, c.words, ' '), err: '', bulk: [] };
      case 'pin': { let p = ''; for (let i = 0; i < 200; i++) { p = this.pickN(C.D, c.digits); if (!c.skip || !this.obviousPin(p)) break; } return { password: p, err: '', bulk: [] }; }
      case 'bulk': { const pool = C.U + C.L + C.D + C.S; const list = []; for (let i = 0; i < c.count; i++) list.push(this.pickN(pool, c.length)); return { password: '', err: '', bulk: list, bulkSel: 0 }; }
      default: return this.genCustom(s, c);
    }
  }

  genCustom(s, c) {
    const C = this.sets();
    if (c.kind === 'words') return { password: this.phrase(s, c.words, c.sep), err: '', bulk: [] };
    if (c.kind === 'pron') { const cs = 'bcdfghjklmnpqrstvwxyz', v = 'aeiou'; let o = ''; for (let i = 0; i < c.pronLen; i++) o += i % 2 === 0 ? cs[this.rnd(21)] : v[this.rnd(5)]; return { password: o, err: '', bulk: [] }; }
    if (c.kind === 'digits') return { password: this.pickN(C.D, c.length), err: '', bulk: [] };
    if (c.kind === 'pattern') {
      const t = c.pattern || ''; let out = '', rand = 0;
      for (let i = 0; i < t.length; i++) {
        const ch = t[i];
        if (ch === '\\') { if (i + 1 < t.length) { out += t[i + 1]; i++; } continue; }
        const set = ch === 'A' ? C.U : ch === 'a' ? C.L : ch === '0' ? C.D : ch === '!' ? C.S : ch === '?' ? C.U + C.L + C.D + C.S : '';
        if (set) { out += set[this.rnd(set.length)]; rand++; } else out += ch;
      }
      if (!rand) return { password: '', err: 'pattern', bulk: [] };
      return { password: out, err: '', bulk: [] };
    }
    const p = this.customPool(c);
    const inc = c.include || '';
    const n = c.length - inc.length;
    if (!p.length) return { password: '', err: 'empty', bulk: [] };
    if (n < 4) return { password: '', err: 'fixed', bulk: [] };
    const out = this.pickN(p, n).split('');
    if (inc) out.splice(this.rnd(n + 1), 0, inc);
    return { password: (c.prefix || '') + out.join('') + (c.suffix || ''), err: '', bulk: [] };
  }

  metrics(s) {
    const L2 = Math.log2; const I = this.icons(); const c = s.cfg[s.recipe]; const C = this.sets(); const notes = [];
    const words = (n) => { const N = this.W(s).length; return { bits: n * L2(N), pool: null, formula: 'log₂(' + N.toLocaleString('en-GB') + ' words) × ' + n + ' = ' + (n * L2(N)).toFixed(1) + ' bits' }; };
    switch (s.recipe) {
      case 'quick': { const p = this.quickPool(c).length; return { bits: c.length * L2(p), pool: p, formula: 'log₂(' + p + ' characters) × ' + c.length + ' = ' + (c.length * L2(p)).toFixed(1) + ' bits', notes: notes }; }
      case 'manager': { const p = 89; return { bits: c.length * L2(p), pool: p, formula: 'log₂(89 characters) × ' + c.length + ' = ' + (c.length * L2(p)).toFixed(1) + ' bits', notes: notes }; }
      case 'form': {
        const r = this.formRules(s); const P = this.formPool(r); const L = this.formLen(r);
        if (this.formConflict(r)) return { bits: 0, pool: null, formula: '—', notes: notes };
        const key = JSON.stringify(r) + L;
        if (this._fk !== key) { let ok = 0; const T = 600; for (let i = 0; i < T; i++) if (this.formOk(this.pickN(P.all, L), r, P)) ok++; this._fk = key; this._ff = Math.max(ok, 1) / T; }
        const bits = L * L2(P.all.length) + L2(this._ff);
        return { bits: bits, pool: P.all.length, formula: 'log₂(' + P.all.length + ') × ' + L + ' + log₂(share meeting every rule ≈ ' + this._ff.toFixed(2) + ') ≈ ' + bits.toFixed(1) + ' bits', notes: notes };
      }
      case 'wifi': return Object.assign(words(c.words), { notes: notes });
      case 'tv': return Object.assign(words(c.words), { notes: notes });
      case 'master': return Object.assign(words(c.words), { notes: notes });
      case 'pin': {
        notes.push({ icon: I.Warning, text: 'Only safe where guesses are limited. Against unlimited guessing, any PIN falls almost at once.' });
        const b = c.digits * L2(10);
        return { bits: b, pool: 10, formula: 'log₂(10) × ' + c.digits + ' = ' + b.toFixed(1) + ' bits' + (c.skip ? ', slightly less with obvious PINs skipped' : ''), notes: notes };
      }
      case 'bulk': return { bits: c.length * L2(89), pool: 89, formula: 'Each: log₂(89) × ' + c.length + ' = ' + (c.length * L2(89)).toFixed(1) + ' bits', notes: notes };
      default: {
        if (c.kind === 'words') return Object.assign(words(c.words), { notes: notes });
        if (c.kind === 'pron') { const a = Math.ceil(c.pronLen / 2), v = Math.floor(c.pronLen / 2); const b = a * L2(21) + v * L2(5); notes.push({ icon: I.Warning, text: 'Sayable, but each character carries about 3.4 bits instead of up to 6.5.' }); return { bits: b, pool: null, formula: a + ' × log₂(21) + ' + v + ' × log₂(5) = ' + b.toFixed(1) + ' bits', notes: notes }; }
        if (c.kind === 'digits') { const b = c.length * L2(10); return { bits: b, pool: 10, formula: 'log₂(10) × ' + c.length + ' = ' + b.toFixed(1) + ' bits', notes: notes }; }
        if (c.kind === 'pattern') {
          let b = 0, lit = 0; const t = c.pattern || '';
          for (let i = 0; i < t.length; i++) { const ch = t[i]; if (ch === '\\') { i++; lit++; continue; } const n = ch === 'A' || ch === 'a' ? 26 : ch === '0' ? 10 : ch === '!' ? C.S.length : ch === '?' ? 89 : 0; if (n) b += L2(n); else lit++; }
          if (lit) notes.push({ icon: I.Info, text: lit + ' typed-as-is character' + (lit > 1 ? 's' : '') + ' add no unpredictability.' });
          return { bits: b, pool: null, formula: 'Sum of log₂(choices) per random slot = ' + b.toFixed(1) + ' bits', notes: notes };
        }
        const p = this.customPool(c).length; const n = Math.max(0, c.length - (c.include || '').length);
        const fixed = (c.include || '').length + (c.prefix || '').length + (c.suffix || '').length;
        if (fixed) notes.push({ icon: I.Info, text: 'Fixed text, prefix and suffix add ' + fixed + ' characters but no unpredictability, so they aren’t counted.' });
        const b = p && n >= 4 ? n * L2(p) : 0;
        return { bits: b, pool: p, formula: 'log₂(' + p + ') × ' + n + ' random = ' + b.toFixed(1) + ' bits', notes: notes };
      }
    }
  }

  tier(bits) {
    const I = this.icons();
    const T = [
      { n: 1, name: 'Very weak', tone: 'var(--st-danger)', soft: 'var(--danger)', icon: I.XCircle, line: 'guessable almost at once' },
      { n: 2, name: 'Weak', tone: 'var(--st-danger)', soft: 'var(--danger)', icon: I.ShieldWarning, line: 'falls fast to an offline attack' },
      { n: 3, name: 'Fair', tone: 'var(--st-warning)', soft: 'var(--warning)', icon: I.Warning, line: 'fine where guesses are limited' },
      { n: 4, name: 'Strong', tone: 'var(--st-success)', soft: 'var(--success)', icon: I.ShieldCheck, line: 'good for almost any account' },
      { n: 5, name: 'Very strong', tone: 'var(--st-success)', soft: 'var(--success)', icon: I.ShieldCheck, line: 'beyond what guessing can reach' }
    ];
    return bits < 28 ? T[0] : bits < 50 ? T[1] : bits < 70 ? T[2] : bits < 100 ? T[3] : T[4];
  }

  crack(bits) {
    if (bits <= 0) return { lg: -3, text: '—', cmp: '' };
    const lg = (bits - 1) * Math.log10(2) - 11;
    const s = Math.pow(10, lg);
    const r = (x) => (x < 10 ? x.toFixed(1).replace('.0', '') : String(Math.round(x)));
    const y = s / 31557600;
    let text;
    if (lg < 0) text = 'less than a second';
    else if (s < 60) text = 'about ' + r(s) + ' seconds';
    else if (s < 3600) text = 'about ' + r(s / 60) + ' minutes';
    else if (s < 86400) text = 'about ' + r(s / 3600) + ' hours';
    else if (y < 1) text = 'about ' + r(s / 86400) + ' days';
    else if (y < 1000) text = 'about ' + r(y) + ' years';
    else if (y < 1e15) { const big = [[1e12, 'trillion'], [1e9, 'billion'], [1e6, 'million'], [1e3, 'thousand']]; for (let i = 0; i < big.length; i++) if (y >= big[i][0]) { text = 'about ' + r(y / big[i][0]) + ' ' + big[i][1] + ' years'; break; } }
    else { const sup = '⁰¹²³⁴⁵⁶⁷⁸⁹'; text = 'about 10' + String(Math.floor(Math.log10(y))).split('').map((d) => sup[+d]).join('') + ' years'; }
    let cmp = '';
    const U = 13.8e9;
    if (y >= U) { const k = y / U; cmp = k < 1000 ? '≈ ' + Math.round(k).toLocaleString('en-GB') + '× the age of the universe' : 'far longer than the universe has existed'; }
    else if (y >= 4.54e9) cmp = 'longer than the Earth has existed';
    else if (y >= 3e5) cmp = 'longer than humans have existed';
    else if (y >= 5000) cmp = 'longer than all of recorded history';
    else if (y >= 80) cmp = 'longer than a lifetime';
    else if (y >= 1) cmp = 'within a lifetime';
    else if (s >= 86400) cmp = 'days, not years';
    else cmp = 'faster than you could read this';
    return { lg: lg, text: text, cmp: cmp };
  }

  stamp(d) { return d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }); }

  defaultCfg() {
    return {
      quick: { length: 16, symbols: true, noSimilar: false },
      manager: { length: 32 },
      form: { text: '', ov: {} },
      wifi: { ssid: '', words: 6, sep: '-' },
      tv: { words: 6 },
      master: { words: 7 },
      pin: { digits: 6, skip: true },
      bulk: { count: 20, length: 16, format: 'txt' },
      custom: { kind: 'random', length: 16, upper: true, lower: true, digits: true, symbols: true, noSimilar: false, exclude: '', include: '', prefix: '', suffix: '', words: 6, sep: '-', pronLen: 12, pattern: 'Aaaa-0000-!!!!' }
    };
  }

  build(sc) {
    const RULES = 'Your password must be 8-16 characters long and include at least one uppercase letter, one number and one special character (!@#$%). Spaces are not allowed.';
    const base = { theme: this.props.theme || 'system', recipe: 'quick', cfg: this.defaultCfg(), wordList: this._loaded || null, revealed: true, spell: false, detail: false, copied: false, copiedKey: '', clearOn: false, clearLeft: 0, breach: 'idle', leakOpen: false, hashFull: '', sim: 'found', failReason: '', offline: false, history: [], gens: 1, consent: 'pending', menu: false, themeMenu: false, sheet: false, readout: false, tray: false, toast: null, note: '', announce: '', tick: -1, bulkSel: 0, peek: '', practice: { input: '', hits: 0, msg: '', ok: null }, roll: null, scenario: sc };
    const P = {
      first: {}, ready: { consent: 'done' }, returning: { consent: 'done', history: 'fill' }, copied: { consent: 'done', history: 'fill', copied: true },
      manager: { consent: 'done', recipe: 'manager' },
      form: { consent: 'done', recipe: 'form', formText: RULES },
      formConflict: { consent: 'done', recipe: 'form', formText: 'Must be 12 to 8 characters. No special characters allowed. Must include a symbol.' },
      wifi: { consent: 'done', recipe: 'wifi' }, wifiQr: { consent: 'done', recipe: 'wifi', ssid: 'Fern-House-5G' },
      words: { consent: 'done', recipe: 'custom', kind: 'words' }, readout: { consent: 'done', recipe: 'wifi', readout: true },
            pin: { consent: 'done', recipe: 'pin' }, bulk: { consent: 'done', recipe: 'bulk' }, bulk500: { consent: 'done', recipe: 'bulk', count: 500, history: 'fill' },
      custom: { consent: 'done', recipe: 'custom' },
      spell: { consent: 'done', spell: true }, hidden: { consent: 'done', revealed: false, history: 'fill' }, detail: { consent: 'done', detail: true, recipe: 'custom', prefix: 'acme-', exclude: 'xyz' },
      checking: { consent: 'done', breach: 'checking', leakOpen: true }, found: { consent: 'done', breach: 'found', sim: 'found', history: 'fill', leakOpen: true }, notfound: { consent: 'done', breach: 'notfound', sim: 'notfound', leakOpen: true }, failed: { consent: 'done', breach: 'failed', sim: 'failed', failReason: 'service', leakOpen: true },
      offline: { consent: 'done', offline: true, history: 'fill' }, share: { consent: 'done', shareOpen: true, history: 'fill' }, poster: { consent: 'done', recipe: 'wifi', ssid: 'Fern-House-5G', posterOpen: true }, drawerEmpty: { consent: 'done', sheet: true }, historySheet: { consent: 'done', history: 'fill', sheet: true }, menu: { consent: 'done', menu: true }, themeMenu: { consent: 'done', themeMenu: true }
    };
    const o = P[sc] || {};
    const st = Object.assign(base, o);
    if (o.formText) st.cfg.form.text = o.formText;
    if (o.ssid) st.cfg.wifi.ssid = o.ssid;
    if (o.count) st.cfg.bulk.count = o.count;
    if (o.kind) st.cfg.custom.kind = o.kind;
    if (o.prefix) { st.cfg.custom.prefix = o.prefix; st.cfg.custom.exclude = o.exclude; }
    Object.assign(st, this.gen(st));
    if (st.history === 'fill') st.history = this.fillHistory(st); else st.history = [];
    if (o.practiceSeed) { const w = st.password.split(' '); w[3] = w[3] + 's'; st.practice = { input: w.join(' '), hits: 1, msg: 'Close — word 4 is different. One out of three so far.', ok: false }; }
    return st;
  }

  fillHistory(s) {
    const out = []; const now = Date.now();
    const kinds = ['quick', 'wifi', 'form', 'pin', 'manager', 'quick'];
    for (let i = 0; i < kinds.length; i++) { const o = Object.assign({}, s, { recipe: kinds[i] }); const g = this.gen(o); if (!g.err) out.push(this.entry(o, g, new Date(now - (i + 1) * 4 * 60000 - i * 37000), i)); }
    return out;
  }

  entry(s, g, d, id) {
    const def = this.recipeDefs().find((r) => r.id === s.recipe);
    const v = s.recipe === 'bulk' ? g.bulk.join('\n') : g.password;
    const label = s.recipe === 'bulk' ? def.name + ' · ' + g.bulk.length : def.name + ' · ' + v.length + ' chars';
    return { id: 'h' + id + '-' + d.getTime(), value: v, label: label, time: this.stamp(d), recipe: s.recipe };
  }

  S() {
    if (!this._b) this._b = this.build(this.props.scenario || 'first');
    return Object.assign({}, this._b, this.state || {});
  }

  componentDidMount() {
    if (this.props.focus) this._ft2 = setTimeout(() => { try { const el = document.querySelector(this.props.focus); let p = el && el.parentElement; while (p && !(p.scrollHeight > p.clientHeight + 4 && /auto|scroll/.test(getComputedStyle(p).overflowY))) p = p.parentElement; if (el && p) p.scrollTop = el.getBoundingClientRect().top - p.getBoundingClientRect().top + p.scrollTop - (el.tagName === 'INPUT' ? 170 : 12); } catch (e) {} }, 350);
    try { const m = /[#&]r=([a-z]+)/.exec(window.location.hash || ''); if (m && !this.props.scenario) { if (m[1] === 'words') { const st = this.S(); const cfg = Object.assign({}, st.cfg); cfg.custom = Object.assign({}, cfg.custom, { kind: 'words' }); this.apply({ recipe: 'custom', cfg: cfg }, ''); } else if (this.recipeDefs().some((r) => r.deck && r.id === m[1])) this.apply({ recipe: m[1] }, ''); } } catch (e) {}
    try {
      fetch('/_blob/e9b9cca83c322f25512aa66d5ed362e1').then((r) => r.json()).then((list) => {
        if (Array.isArray(list)) list = list.filter((w) => w !== 'undefined');
        if (!Array.isArray(list) || list.length < 1000) return;
        this._loaded = list;
        const s = this.S();
        const patch = { wordList: list };
        if (['wifi', 'tv', 'master'].indexOf(s.recipe) >= 0 || (s.recipe === 'custom' && s.cfg.custom.kind === 'words')) {
          Object.assign(patch, this.gen(Object.assign({}, s, { wordList: list })));
          if (s.scenario === 'practice') { const w = patch.password.split(' '); w[3] = w[3] + 's'; patch.practice = { input: w.join(' '), hits: 1, msg: 'Close — word 4 is different. One out of three so far.', ok: false }; }
        }
        this.setState(patch);
      }).catch(() => {});
    } catch (e) {}
    this.hashOf(this.current(this.S())).then((h) => this.setState({ hashFull: h }));
  }

  componentWillUnmount() { clearTimeout(this._bt); clearTimeout(this._ct); clearTimeout(this._tt); clearInterval(this._clr); cancelAnimationFrame(this._raf); }

  current(s) { return s.recipe === 'bulk' ? (s.bulk[s.bulkSel] || '') : s.password; }

  hashOf(pw) {
    try { return crypto.subtle.digest('SHA-1', new TextEncoder().encode(pw || '')).then((b) => Array.from(new Uint8Array(b)).map((x) => x.toString(16).padStart(2, '0')).join('').toUpperCase()).catch(() => ''); }
    catch (e) { return Promise.resolve(''); }
  }

  reduced() { try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return true; } }

  startRoll(pw) {
    if (this.reduced() || !pw || pw.length > 64) return;
    const t0 = performance.now();
    const step = () => {
      const el = performance.now() - t0;
      if (el > 520) { this.setState({ roll: null }); return; }
      this.setState({ roll: el });
      this._raf = requestAnimationFrame(step);
    };
    cancelAnimationFrame(this._raf);
    this._raf = requestAnimationFrame(step);
  }

  apply(patch, why) {
    const s = this.S();
    const ns = Object.assign({}, s, patch);
    const g = this.gen(ns);
    const b = this.metrics(s), a = this.metrics(ns);
    let note = '';
    if (why && b.bits && a.bits) { const tb = this.tier(b.bits), ta = this.tier(a.bits); note = why + ': ' + Math.round(b.bits) + ' → ' + Math.round(a.bits) + ' bits.' + (ta.n !== tb.n ? ' Now ' + ta.name + ' (was ' + tb.name + ').' : ''); }
    this.setState(Object.assign({}, patch, g, { note: note, breach: 'idle', copied: false, hashFull: '' }));
    this.hashOf(this.current(Object.assign({}, ns, g))).then((h) => this.setState({ hashFull: h }));
    this.startRoll(g.password);
  }

  setCfg(key, patch, why) {
    const s = this.S();
    const cfg = Object.assign({}, s.cfg); cfg[key] = Object.assign({}, cfg[key], patch);
    this.apply({ cfg: cfg }, why);
  }

  regen() {
    const s = this.S();
    const g = this.gen(s);
    const patch = Object.assign({}, g, { copied: false, breach: 'idle', hashFull: '', note: '', tick: s.tick + 1, gens: s.gens + 1 });
    if (!g.err) {
      const e = this.entry(s, g, new Date(), s.gens + 1);
      patch.history = [e].concat(s.history.filter((h) => h.value !== e.value)).slice(0, 20);
      patch.announce = 'New password cut. ' + this.tier(this.metrics(s).bits).name + '.';
    }
    if (s.recipe === 'master') patch.practice = { input: '', hits: 0, msg: '', ok: null };
    this.setState(patch);
    this.hashOf(this.current(Object.assign({}, s, g))).then((h) => this.setState({ hashFull: h }));
    this.startRoll(g.password);
  }

  writeClip(text) {
    try { if (navigator.clipboard && navigator.clipboard.writeText) return navigator.clipboard.writeText(text).then(() => true, () => false); } catch (e) {}
    return Promise.resolve(false);
  }

  toast(kind, text) {
    const I = this.icons();
    const icon = kind === 'error' ? I.Warning : kind === 'ok' ? I.Check : kind === 'download' ? I.Download : I.Info;
    this.setState({ toast: { icon: icon, text: text }, announce: text });
    clearTimeout(this._tt); this._tt = setTimeout(() => this.setState({ toast: null }), 6000);
  }

  copyValue(text, key, label, log) {
    this.writeClip(text).then((ok) => {
      if (!ok) { this.toast('error', 'Couldn’t reach the clipboard here. Select the password and copy it yourself.'); return; }
      const s = this.S();
      const patch = { copiedKey: key, announce: label + ' copied.' };
      if (key === 'main') patch.copied = true;
      if (log) { const e = this.entry(s, { password: s.password, bulk: s.bulk }, new Date(), s.gens); patch.history = [e].concat(s.history.filter((h) => h.value !== e.value)).slice(0, 20); }
      this.setState(patch);
      clearTimeout(this._ct); this._ct = setTimeout(() => this.setState({ copiedKey: '' }), 2000);
      if (key === 'main' && s.clearOn) this.armClear();
    });
  }

  armClear() {
    clearInterval(this._clr);
    this.setState({ clearLeft: 60 });
    this._clr = setInterval(() => {
      const left = (this.S().clearLeft || 0) - 1;
      if (left <= 0) {
        clearInterval(this._clr);
        this.writeClip(' ').then((ok) => { this.setState({ clearLeft: 0 }); this.toast(ok ? 'ok' : 'error', ok ? 'Clipboard cleared.' : 'Couldn’t clear the clipboard — this tab wasn’t in focus. Copy something else to overwrite it.'); });
      } else this.setState({ clearLeft: left });
    }, 1000);
  }

  loreSvg(mood) {
    const eye = (x, y, r) => 'M' + (x - r) + ' ' + y + 'a' + r + ' ' + r + ' 0 1 0 ' + (2 * r) + ' 0a' + r + ' ' + r + ' 0 1 0 ' + (-2 * r) + ' 0';
    const face = mood === 'cool'
      ? '<path d="M42 56h22a3 3 0 0 1 3 3v4a10 10 0 0 1-10 10h-6a10 10 0 0 1-10-10v-4a3 3 0 0 1 3-3z M74 56h22a3 3 0 0 1 3 3v4a10 10 0 0 1-10 10h-6a10 10 0 0 1-10-10v-4a3 3 0 0 1 3-3z M66 60h9" fill="#0B0D17"/><path d="M56 82Q70 98 84 82Z" fill="#0B0D17"/>'
      : mood === 'worried'
        ? '<path d="' + eye(56, 64, 6.5) + ' ' + eye(84, 64, 6.5) + '" fill="#0B0D17"/><path d="M46 56l12-6 M94 56l-12-6 M60 90Q70 81 80 90" fill="none" stroke="#0B0D17" stroke-width="3.5" stroke-linecap="round"/>'
        : '<path d="' + eye(56, 66, 5) + ' ' + eye(84, 66, 5) + '" fill="#0B0D17"/><path d="M56 80Q70 98 84 80Z" fill="#0B0D17"/>';
    return '<g transform="rotate(-8 80 70)"><path d="M60 104v14h-9 M80 104v14h9" fill="none" stroke="#0B0D17" stroke-width="3.5" stroke-linecap="round"/><path d="M88 58H142a7 7 0 0 1 7 7v6a7 7 0 0 1-7 7H88Z" fill="#2447F5" stroke="#0B0D17" stroke-width="3"/><path d="M116 78v13h9v-7h7v7h9V78" fill="#2447F5" stroke="#0B0D17" stroke-width="3" stroke-linejoin="round"/><path d="M34 56Q22 36 30 22" fill="none" stroke="#0B0D17" stroke-width="3.5" stroke-linecap="round"/><circle cx="30" cy="20" r="6.5" fill="#C8FF2E" stroke="#0B0D17" stroke-width="3"/><circle cx="70" cy="68" r="40" fill="#C8FF2E" stroke="#0B0D17" stroke-width="3.5"/><path d="M44 42a34 34 0 0 1 22-11" fill="none" stroke="#FFFFFF" stroke-width="5" stroke-linecap="round" opacity=".8"/>' + face + '</g>';
  }

  cardSvg(time, tr, m, isWords) {
    const esc = (t) => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const what = isWords ? 'passphrase' : 'password';
    const words = ('would take ' + time + ' to guess.').split(' ');
    const lines = []; let cur = '';
    words.forEach((w) => { if ((cur + ' ' + w).trim().length > 20) { lines.push(cur.trim()); cur = w; } else cur += ' ' + w; });
    if (cur.trim()) lines.push(cur.trim());
    const mood = tr.n >= 5 ? 'cool' : tr.n >= 3 ? 'happy' : 'worried';
    const font = "Sora, 'Plus Jakarta Sans', Arial, Helvetica, sans-serif";
    let y = 230;
    const body = lines.map((l) => { const t = '<text x="70" y="' + y + '" font-family="' + font + '" font-weight="800" font-size="64" letter-spacing="-1.5" fill="#0B0D17">' + esc(l) + '</text>'; y += 74; return t; }).join('');
    return '<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630">'
      + '<rect width="1200" height="630" fill="#C8FF2E"/><rect x="10" y="10" width="1180" height="610" rx="28" fill="none" stroke="#0B0D17" stroke-width="6"/>'
      + '<path d="M1040 70l8 20 20 8-20 8-8 20-8-20-20-8 20-8z M1120 200l5 13 13 5-13 5-5 13-5-13-13-5 13-5z" fill="#FFFFFF" stroke="#0B0D17" stroke-width="4"/>'
      + '<text x="70" y="130" font-family="' + font + '" font-weight="800" font-size="28" letter-spacing="3" fill="#0B0D17">MY NEW ' + what.toUpperCase() + '</text>'
      + body
      + '<text x="70" y="' + (y + 10) + '" font-family="' + font + '" font-weight="700" font-size="26" fill="#0B0D17">' + esc(tr.name + ' · ≈ ' + Math.round(m.bits) + ' bits · estimate') + '</text>'
      + '<g transform="translate(780 150) scale(2.4)">' + this.loreSvg(mood) + '</g>'
      + '<text x="70" y="580" font-family="' + font + '" font-weight="800" font-size="30" fill="#0B0D17">passlore.com</text>'
      + '<text x="1130" y="580" text-anchor="end" font-family="' + font + '" font-weight="700" font-size="24" fill="#0B0D17">Made on my device · the password never left it</text>'
      + '</svg>';
  }

  cardPng(time, tr, m, isWords) {
    return new Promise((resolve) => {
      try {
        const img = new Image();
        img.onload = () => { try { const c = document.createElement('canvas'); c.width = 1200; c.height = 630; c.getContext('2d').drawImage(img, 0, 0); c.toBlob((b) => resolve(b), 'image/png'); } catch (x) { resolve(null); } };
        img.onerror = () => resolve(null);
        img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(this.cardSvg(time, tr, m, isWords));
      } catch (x) { resolve(null); }
    });
  }

  shareCard(text, time, tr, m, isWords) {
    const fallback = () => this.writeClip(text).then((ok) => this.toast(ok ? 'ok' : 'error', ok ? 'Sharing isn’t available here, so the text was copied — no password in it.' : 'Sharing isn’t available here.'));
    this.cardPng(time, tr, m, isWords).then((b) => {
      try {
        if (b && navigator.canShare) { const f = new File([b], 'passlore-strength.png', { type: 'image/png' }); if (navigator.canShare({ files: [f] })) { navigator.share({ files: [f], text: text }).catch(() => {}); return; } }
        if (navigator.share) { navigator.share({ text: text, url: 'https://passlore.com' }).catch(() => {}); return; }
      } catch (x) {}
      fallback();
    });
  }

  renderVals() {
    const s = this.S();
    const I = this.icons();
    const defs = this.recipeDefs();
    const def = defs.find((r) => r.id === s.recipe) || defs[0];
    const c = s.cfg[s.recipe];
    const m = this.metrics(s);
    const tr = this.tier(m.bits);
    const ck = this.crack(m.bits);
    const shareTime = (ck.text || '').replace(/^about /, '');
    const shareText = 'My new ' + (s.recipe === 'pin' ? 'PIN' : 'password') + ' would take ' + (ck.text || '') + ' to guess (estimate) — and Passlore never saw it. Cut yours at passlore.com';
    const C = this.sets();
    const kindOf = (ch) => (C.D.indexOf(ch) >= 0 ? 'digit' : C.U.indexOf(ch) >= 0 ? 'upper' : C.L.indexOf(ch) >= 0 ? 'lower' : ch === ' ' ? 'space' : 'symbol');
    const colorOf = (k) => (k === 'digit' ? 'var(--digit)' : k === 'symbol' ? 'var(--sym)' : 'var(--text)');
    const nato = { a: 'alfa', b: 'bravo', c: 'charlie', d: 'delta', e: 'echo', f: 'foxtrot', g: 'golf', h: 'hotel', i: 'india', j: 'juliett', k: 'kilo', l: 'lima', m: 'mike', n: 'november', o: 'oscar', p: 'papa', q: 'quebec', r: 'romeo', s: 'sierra', t: 'tango', u: 'uniform', v: 'victor', w: 'whiskey', x: 'x-ray', y: 'yankee', z: 'zulu' };
    const digitW = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'];
    const symName = { '!': 'exclamation', '@': 'at', '#': 'hash', '$': 'dollar', '%': 'percent', '^': 'caret', '&': 'ampersand', '*': 'asterisk', '(': 'open paren', ')': 'close paren', '-': 'hyphen', '_': 'underscore', '=': 'equals', '+': 'plus', '[': 'open bracket', ']': 'close bracket', '{': 'open brace', '}': 'close brace', ';': 'semicolon', ':': 'colon', ',': 'comma', '.': 'dot', '<': 'less than', '>': 'greater than', '/': 'slash', '?': 'question', '~': 'tilde', ' ': 'space', '\\': 'backslash', '|': 'bar' };
    const sayChar = (ch) => { const k = kindOf(ch); if (k === 'upper') return 'capital ' + nato[ch.toLowerCase()]; if (k === 'lower') return nato[ch]; if (k === 'digit') return digitW[+ch]; return symName[ch] || ch; };
    const isWords = ['wifi', 'tv', 'master'].indexOf(s.recipe) >= 0 || (s.recipe === 'custom' && c.kind === 'words');
    let shownPw = s.password;
    if (s.roll != null && s.password) {
      const pool = isWords ? 'abcdefghijklmnopqrstuvwxyz' : (s.recipe === 'pin' ? C.D : C.U + C.L + C.D + C.S);
      const per = Math.min(22, 380 / Math.max(1, s.password.length));
      shownPw =s.password.split('').map((ch, i) => (ch === ' ' || (isWords && /[-._]/.test(ch)) || s.roll >= 120 + i * per ? ch : pool[Math.floor(Math.random() * pool.length)])).join('');
    }
    const display = s.revealed ? shownPw : s.password.replace(/./g, '•');
    const chars = display.split('').map((ch) => ({ ch: ch, color: s.revealed ? colorOf(kindOf(ch)) : 'var(--text-3)' }));
    const spellTiles = s.password.split('').map((ch, i) => { const k = kindOf(ch); return { ch: ch === ' ' ? '␣' : ch, word: k === 'upper' ? 'CAP ' + nato[ch.toLowerCase()] : k === 'lower' ? nato[ch] : k === 'digit' ? digitW[+ch] : (symName[ch] || 'symbol'), color: colorOf(k), aria: (i + 1) + ': ' + sayChar(ch) }; });
    const themeDefs = [['system', 'System', 'Auto', I.Monitor], ['light', 'Light', 'Light', I.Sun], ['dark', 'Dark', 'Dark', I.Moon], ['sepia', 'Sepia', 'Sepia', I.Book], ['hc', 'High contrast', 'Contrast', I.CircleHalf]];
    const thI = Math.max(0, themeDefs.findIndex((t) => t[0] === s.theme));
    const pickTheme = (id) => () => this.setState({ theme: id, themeMenu: false });
    const deckOf = (r) => ({ form: 'custom', bulk: 'custom', tv: 'custom', master: 'custom' }[r] || r);
    const pickRecipe = (id) => { if (id === deckOf(s.recipe)) return; this.apply({ recipe: id, spell: false, readout: false, detail: false }, ''); this.setState({ announce: 'Recipe: ' + defs.find((d) => d.id === id).name }); };
    const shorts = { quick: 'Just one', manager: 'Manager', form: 'Form', wifi: 'Wi-Fi', tv: 'TV', master: 'Master', pin: 'PIN', bulk: 'Many', custom: 'Custom' };
    const deckDefs = defs.filter((d) => d.deck);
    const recipes = deckDefs.map((r) => { const on = r.id === deckOf(s.recipe); return { cls: 'rc ' + r.cls, short: shorts[r.id], name: r.name, line: r.line, icon: r.icon, sel: on ? 'true' : 'false', sel2: on, tab: on ? 0 : -1, pick: () => pickRecipe(r.id) }; });
    const bk = s.recipe === 'form' ? 'rules' : s.recipe === 'bulk' ? 'many' : (s.cfg.custom.kind === 'words' ? 'words' : 'random');
    const pickBuild = (k) => { if (k === bk) return; if (k === 'rules') this.apply({ recipe: 'form', spell: false, readout: false }, ''); else if (k === 'many') this.apply({ recipe: 'bulk', spell: false, readout: false }, ''); else { const cfg = Object.assign({}, s.cfg); cfg.custom = Object.assign({}, cfg.custom, { kind: k }); this.apply({ recipe: 'custom', cfg: cfg, spell: false, readout: false }, ''); } this.setState({ announce: 'Build your own: ' + { random: 'characters', words: 'words', rules: 'fit a site’s rules', many: 'many at once' }[k] }); };
    const formR = s.recipe === 'form' ? this.formRules(s) : null;
    const conflict = formR ? this.formConflict(formR) : null;
    const errMap = {
      empty: ['Nothing left to pick from', 'Every character type is off or excluded.', 'Turn lowercase back on', () => this.setCfg('custom', { lower: true, exclude: '' }, '')],
      fixed: ['Fixed text leaves too little room', 'Fewer than 4 random characters would be left. Make it longer or the fixed text shorter.', 'Make it longer', () => this.setCfg('custom', { length: Math.min(128, (c.include || '').length + 12) }, '')],
      pattern: ['This pattern has no random slots', 'Every character is typed as-is, so every password would be identical.', 'Use Aaaa-0000-!!!!', () => this.setCfg('custom', { pattern: 'Aaaa-0000-!!!!' }, '')],
      form: conflict ? [conflict.title, conflict.text, conflict.fix, () => { const ov = Object.assign({}, s.cfg.form.ov, conflict.patch); this.setCfg('form', { ov: ov }, ''); }] : ['These rules can’t be met', 'Passlore couldn’t find a password that satisfies every rule. Loosen one below.', 'Clear the rules', () => this.setCfg('form', { text: '', ov: {} }, '')]
    };
    const e = s.err ? errMap[s.err] : null;
    const lore = e ? ['shocked', 'none', 'These rules fight each other — fix one below and I’ll cut again.']
      : s.copied ? ['proud', 'confetti', 'Copied! Now paste it where it’s going.']
      : !s.revealed ? ['wink', 'none', 'Hidden from shoulder-surfers. Copy still works.']
      : tr.n <= 1 ? ['worried', 'none', 'Eek — that’s guessable almost at once.']
      : tr.n === 2 ? ['worried', 'none', 'Hmm. That falls fast if a site leaks.']
      : tr.n === 3 ? ['flat', 'none', 'Fine where guesses are limited. Longer is better.']
      : tr.n === 4 ? ['happy', 'none', 'Nice — strong enough for almost any account.']
      : ['cool', 'sparkles', 'Beyond what guessing can reach. Sunglasses on.'];
    const noOutput = !!e || (s.recipe === 'bulk' ? s.bulk.length === 0 : !s.password);
    const noSingle = !!e || s.recipe === 'bulk';
    let lenCfg = null;
    if (s.recipe === 'quick') lenCfg = ['Length', 8, 64, c.length, 'length'];
    else if (s.recipe === 'manager') lenCfg = ['Length', 16, 128, c.length, 'length'];
    else if (s.recipe === 'wifi' || s.recipe === 'tv') lenCfg = ['Words', 4, 9, c.words, 'words'];
    else if (s.recipe === 'master') lenCfg = ['Words', 5, 10, c.words, 'words'];
    else if (s.recipe === 'bulk') lenCfg = ['Length of each', 8, 64, c.length, 'length'];
    else if (s.recipe === 'custom') lenCfg = c.kind === 'words' ? ['Words', 3, 10, c.words, 'words'] : c.kind === 'pron' ? ['Length', 6, 32, c.pronLen, 'pronLen'] : c.kind === 'pattern' ? null : ['Length', 4, 128, c.length, 'length'];
    const onLen = (ev) => { if (!lenCfg) return; const v = Math.max(lenCfg[1], Math.min(lenCfg[2], parseInt(ev.target.value, 10) || lenCfg[1])); const p = {}; p[lenCfg[4]] = v; this.setCfg(s.recipe, p, lenCfg[0] + ' ' + lenCfg[3] + ' → ' + v); };
    const pct = (lg) => Math.max(0, Math.min(100, ((lg + 2) / 32) * 100)).toFixed(1) + '%';
    const marks = [['a second', 0], ['an hour', 3.556], ['a year', 7.499], ['a lifetime', 9.402], ['recorded history', 11.198], ['age of the universe', 17.639]];
    const outMeta = e ? '' : s.recipe === 'bulk' ? s.bulk.length + ' passwords · ' + c.length + ' characters each' : (s.revealed ? '' : 'Hidden · ') + s.password.length + ' characters' + (isWords ? ' · ' + s.password.split(/[ \-._]/).length + ' words' : '') + (m.pool && !isWords && s.recipe !== 'pin' ? ' · from ' + m.pool : '');
    const nextMap = {
      wifi: ['Change the password in your router’s settings', 'Show the QR to guests, or read it out', 'Close this tab when done — the drawer empties'],
      tv: ['Type it on the TV, word by word', 'Save it in your password manager too', 'Close this tab when done — the drawer empties'],
      master: ['Set it in your password manager', 'Practise it below until it sticks', 'Keep a paper copy at home for now'],
      pin: ['Set it on the device', 'Don’t write it next to the device', 'Never reuse it for a card and a phone'],
      bulk: ['Hand each one to its owner', 'Ask them to change it at first sign-in', 'Delete any exported file'],
      _: ['Paste it into the site', 'Save it in your password manager', 'Close this tab when done — the drawer empties']
    };
    const steps = (nextMap[s.recipe] || nextMap._).map((t, i) => ({ i: i + 1, t: t }));
    const fp = formR ? this.formPool(formR) : null;
    const fitList = [];
    if (formR && !conflict && s.password) {
      const pw = s.password; const L = pw.length;
      const lenTxt = (formR.min != null ? formR.min : 1) + '–' + (formR.max != null ? formR.max : '∞') + ' characters';
      fitList.push({ ok: L >= (formR.min || 0) && L <= (formR.max || 999), text: lenTxt + ' → ' + L + ' (the longest allowed)' });
      if (formR.upper) fitList.push({ ok: /[A-Z]/.test(pw), text: 'An uppercase letter' });
      if (formR.lower) fitList.push({ ok: /[a-z]/.test(pw), text: 'A lowercase letter' });
      if (formR.digit) fitList.push({ ok: /[0-9]/.test(pw), text: 'A number' });
      if (formR.symbol) fitList.push({ ok: pw.split('').some((x) => fp.S.indexOf(x) >= 0), text: 'A symbol' + (formR.syms ? ' from ' + formR.syms : '') });
      if (formR.syms != null || formR.noSymbols) fitList.push({ ok: pw.split('').every((x) => /[A-Za-z0-9]/.test(x) || fp.S.indexOf(x) >= 0), text: formR.noSymbols ? 'No symbols at all' : 'Only the symbols it accepts' });
      if (formR.startLetter) fitList.push({ ok: /^[A-Za-z]/.test(pw), text: 'Starts with a letter' });
      fitList.push({ ok: pw.indexOf(' ') < 0, text: 'No spaces' });
    }
    const p = formR ? formR.parsed : null;
    const chips = [];
    if (formR) {
      const ov = s.cfg.form.ov || {};
      const mk = (key, label, on) => chips.push({ cls: on ? 'chip' : 'chip off', label: label, aria: (on ? 'Ignore rule: ' : 'Use rule: ') + label, icon: on ? I.X : I.Plus, toggle: () => { const n = Object.assign({}, ov); n[key] = !on; this.setCfg('form', { ov: n }, ''); } });
      if (p.min != null || p.max != null) chips.push({ cls: 'chip', label: (p.min != null ? p.min : '?') + '–' + (p.max != null ? p.max : '?') + ' characters', aria: 'Length rule from the text', icon: I.Check, toggle: () => {} });
      if (p.upper) mk('upper', 'Uppercase letter', formR.upper);
      if (p.lower) mk('lower', 'Lowercase letter', formR.lower);
      if (p.digit) mk('digit', 'A number', formR.digit);
      if (p.symbol) mk('symbol', 'A symbol', formR.symbol);
      if (p.syms) chips.push({ cls: 'chip', label: 'Symbols: ' + p.syms, aria: 'Allowed symbols from the text', icon: I.Check, toggle: () => {} });
      if (p.noSymbols) mk('noSymbols', 'No symbols', formR.noSymbols);
      if (p.startLetter) mk('startLetter', 'Starts with a letter', formR.startLetter);
      if (p.noSpaces) chips.push({ cls: 'chip', label: 'No spaces', aria: 'No spaces', icon: I.Check, toggle: () => {} });
    }
    const pwForQr = s.password;
    let qrPath = '', qrN = 0;
    const ssid = s.cfg.wifi.ssid || '';
    if (s.recipe === 'wifi' && ssid && pwForQr && typeof qrcode !== 'undefined') {
      try {
        const esc = (x) => x.replace(/([\\;,:"])/g, '\\$1');
        const qr = qrcode(0, 'M'); qr.addData('WIFI:T:WPA;S:' + esc(ssid) + ';P:' + esc(pwForQr) + ';;'); qr.make();
        qrN = qr.getModuleCount(); const parts = [];
        for (let r = 0; r < qrN; r++) for (let col = 0; col < qrN; col++) if (qr.isDark(r, col)) parts.push('M' + col + ' ' + r + 'h1v1h-1z');
        qrPath = parts.join('');
      } catch (err) { qrPath = ''; }
    }
    const hashFull = s.hashFull || '';
    const bState = s.breach;
    const bMap = {
      found: ['Found in leak data — don’t use this one', 'This exact password appears 1,284 times in Have I Been Pwned’s data. Attackers try known passwords first.', 'var(--danger)', 'var(--danger-soft)', I.XCircle],
      notfound: ['Not in the leak data', 'A good sign, not proof of safety: it could still leak tomorrow, and reuse would undo it.', 'var(--success)', 'var(--success-soft)', I.CheckCircle],
      failed: ['Couldn’t check — unknown', (s.offline || s.failReason === 'offline') ? 'You’re offline. Unknown doesn’t mean safe.' : 'The service didn’t answer. Unknown doesn’t mean safe — try again in a moment.', 'var(--warning)', 'var(--warning-soft)', I.Question]
    };
    const b = bMap[bState] || bMap.failed;
    const hist = s.history.map((h) => {
      const rd = defs.find((d) => d.id === h.recipe) || defs[0];
      const peek = s.peek === h.id;
      const one = h.value.replace(/\n/g, ' ');
      return { cls: rd.cls, icon: rd.icon, shown: peek ? one : one.replace(/./g, '•').slice(0, 32), ls: peek ? '0.02em' : '0.08em', label: h.label, time: h.time, aria: 'Copy ' + h.label + ' from ' + h.time, peekAria: 'Hold to peek at ' + h.label + ' from ' + h.time, copyIcon: s.copiedKey === h.id ? I.Check : I.Copy, copy: () => this.copyValue(h.value, h.id, rd.name + ' password', false), peekOn: () => this.setState({ peek: h.id }), peekOff: () => this.setState({ peek: '' }), peekKey: (ev) => { if (ev.key === ' ' || ev.key === 'Enter') { ev.preventDefault(); this.setState({ peek: h.id }); } } };
    });
    const today = new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    const bulkRows = s.bulk.slice(0, 500).map((v, i) => ({ n: String(i + 1), shown: s.revealed ? v : v.replace(/./g, '•'), sel: i === s.bulkSel ? 'true' : 'false', bg: i === s.bulkSel ? 'var(--primary-soft)' : 'transparent', selLabel: 'Select password ' + (i + 1) + ' for the leak check', select: () => { this.setState({ bulkSel: i, breach: 'idle', hashFull: '' }); this.hashOf(v).then((h) => this.setState({ hashFull: h })); }, copyLabel: 'Copy password ' + (i + 1), copyIcon: s.copiedKey === 'b' + i ? I.Check : I.Copy, copy: () => this.copyValue(v, 'b' + i, 'Password ' + (i + 1), false) }));
    const fmt = s.cfg.bulk.format;
    const scen = [['first', 'J1 · First visit'], ['ready', 'Ready (consent answered)'], ['copied', 'J1 · Copied + next steps'], ['manager', 'Password manager'], ['wifi', 'J3 · Wi-Fi'], ['wifiQr', 'J3 · Wi-Fi with QR'], ['readout', 'J3 · Show big'], ['pin', 'J4 · PIN'], ['custom', 'J5 · Build your own · characters'], ['words', 'J5 · Build your own · words'], ['form', 'J2 · Build your own · site rules'], ['formConflict', 'J2 · Rules contradict'], ['bulk', 'J6 · Build your own · many'], ['bulk500', 'J6 · 500 at once'], ['detail', 'J7 · Strength detail'], ['checking', 'J8 · Leak check running'], ['found', 'J8 · Found'], ['notfound', 'J8 · Not found'], ['failed', 'J8 · Couldn’t check'], ['spell', 'J9 · Spelled out'], ['hidden', 'J9 · Hidden'], ['historySheet', 'J10 · Drawer'], ['drawerEmpty', 'J10 · Drawer, empty'], ['share', 'J12 · Strength card (share)'], ['poster', 'J3 · Wi-Fi guest poster'], ['themeMenu', 'J11 · Theme menu'], ['offline', 'Offline'], ['menu', 'Menu (phone)']];
    const faq = [
      ['Is Passlore free?', 'Yes. No paid tier, no account, no ads. Open source under the MIT licence.'],
      ['Does Passlore see my passwords?', 'No. Everything is cut in your browser. Pasted rules, network names and practice typing stay on the page too.'],
      ['Why does it ask where the password is going?', 'Because the right password depends on the lock: a TV wants easy typing, a picky form wants its rules met, Wi-Fi wants something you can read out. You can always ignore the question and copy.'],
      ['How random is it?', 'It uses crypto.getRandomValues, the browser’s secure random source, with rejection sampling so every allowed character or word is equally likely.'],
      ['What does the ruler mean?', 'It places the average time to guess the password on a scale from a second to the age of the universe, assuming a fast offline attack. It’s an estimate, never a guarantee.'],
      ['How does the rules reader work?', 'Simple pattern matching on your device: it looks for lengths, required character types and accepted symbols. Always check the chips — you can switch any rule off or set it by hand.'],
      ['What does the leak check send?', 'Only the first 5 of the 40 characters of the password’s SHA-1 hash, to Have I Been Pwned. Matching happens here.'],
      ['Is the Wi-Fi QR code safe to share?', 'Anyone who scans it can join your network, so show it only to people you’d tell the password to. It’s drawn on your device.'],
      ['Should I keep passwords in Passlore?', 'No. It’s a generator, not a vault — the drawer is plain text and empties when you close the tab. Use a password manager.'],
      ['Does it work offline?', 'Yes, every recipe works once the page has loaded. Only the leak check needs a connection.']
    ];
    const bigWords = isWords ? s.password.split(/[ \-._]/).map((t, i) => ({ n: i + 1, t: t })) : s.password.match(/.{1,4}/g) ? s.password.match(/.{1,4}/g).map((t, i) => ({ n: i + 1, t: t })) : [];
    const practice = s.practice || { input: '', hits: 0, msg: '', ok: null };
    const checkPractice = () => {
      const norm = (x) => x.trim().toLowerCase().replace(/\s+/g, ' ');
      const want = norm(s.password), got = norm(practice.input || '');
      if (!got) return;
      if (got === want) { const hits = Math.min(3, practice.hits + 1); this.setState({ practice: { input: '', hits: hits, ok: true, msg: hits >= 3 ? 'Three in a row. It’s yours.' : 'Correct — ' + hits + ' of 3. Hide it and go again.' } }); }
      else { const a = want.split(' '), g = got.split(' '); let k = 0; while (k < a.length && a[k] === g[k]) k++; this.setState({ practice: { input: practice.input, hits: 0, ok: false, msg: k < a.length ? 'Close — word ' + (k + 1) + ' is different. The streak starts over.' : 'Extra words at the end. The streak starts over.' } }); }
    };
    return {
      I: I, theme: s.theme, announce: s.announce,
      markClass: s.tick < 0 ? '' : 'mk' + (s.tick % 2),
      offline: s.offline,
      themeMenu: s.themeMenu, themeMenuExp: s.themeMenu ? 'true' : 'false', toggleThemeMenu: () => this.setState({ themeMenu: !s.themeMenu }),
      themeIcon: themeDefs[thI][3], themeName: themeDefs[thI][1], themeAria: 'Theme: ' + themeDefs[thI][1],
      themes: themeDefs.map((t) => ({ name: t[1], icon: t[3], on: t[0] === s.theme, checked: t[0] === s.theme ? 'true' : 'false', pick: pickTheme(t[0]) })),
      menu: s.menu, menuExp: s.menu ? 'true' : 'false', menuAria: s.menu ? 'Close menu' : 'Open menu', menuIcon: s.menu ? I.X : I.List, toggleMenu: () => this.setState({ menu: !s.menu }),
      install: () => this.toast('info', 'Your browser’s own install prompt opens here (Add to Home Screen on iPhone).'),
      openDrawer: () => this.setState({ sheet: true }), drawerAria: 'Open this tab’s drawer, ' + hist.length + ' items',
      recipes: recipes,
      deckKey: (ev) => { const order = deckDefs.map((d) => d.id); let i = order.indexOf(deckOf(s.recipe)); if (ev.key === 'ArrowRight' || ev.key === 'ArrowDown') i = (i + 1) % order.length; else if (ev.key === 'ArrowLeft' || ev.key === 'ArrowUp') i = (i + order.length - 1) % order.length; else return; ev.preventDefault(); pickRecipe(order[i]); setTimeout(() => { try { const el = ev.currentTarget || document.querySelector('.deck'); const btns = (el ? el : document).querySelectorAll('[role=radio]'); if (btns[i]) btns[i].focus(); } catch (x) {} }, 0); },
      recipeCls: def.cls, recipeIcon: def.icon, recipeName: def.name, ticketAria: 'Password for ' + def.name,
      outMeta: outMeta,
      hasError: !!e, errorTitle: e ? e[0] : '', errorText: e ? e[1] : '', errorFixLabel: e ? e[2] : '', errorFix: () => e && e[3](),
      showOne: !e && s.recipe !== 'bulk', wordBreak: isWords ? 'normal' : 'break-all', chars: chars,
      pwSr: s.revealed ? 'Password: ' + s.password.split('').map(sayChar).join(', ') : 'Password hidden.',
      showBulk: !e && s.recipe === 'bulk', bulkTitle: s.bulk.length + ' passwords, cut', bulkPeek: s.bulk.slice(0, 3).map((v) => (s.revealed ? v : v.replace(/./g, '•'))),
      spellOpen: s.spell && !noSingle && s.revealed, spellTiles: spellTiles,
      hiddenPressed: s.revealed ? 'false' : 'true', revealLabel: s.revealed ? 'Hide password' : 'Show password', revealIcon: s.revealed ? I.EyeSlash : I.Eye,
      toggleReveal: () => this.setState({ revealed: !s.revealed, announce: s.revealed ? 'Password hidden.' : 'Password shown.' }),
      spellPressed: s.spell ? 'true' : 'false', toggleSpell: () => this.setState({ spell: !s.spell }),
      speak: () => {
        try {
          const text = isWords ? s.password.replace(/[-._]/g, ' ') : s.password.split('').map(sayChar).join(', ');
          window.speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(text); u.rate = 0.85; window.speechSynthesis.speak(u);
          this.toast('info', 'Reading aloud — make sure nobody nearby is listening.');
        } catch (x) { this.toast('error', 'This browser can’t read aloud. Try Spell it out instead.'); }
      },
      share: () => { if (navigator.share) navigator.share({ text: s.password }).catch(() => {}); else this.copyValue(s.password, 'main', 'Sharing isn’t available here, so the password was', true); },
      canBig: isWords && !e, openReadout: () => this.setState({ readout: true }), readout: s.readout, closeReadout: () => this.setState({ readout: false }),
      bigWords: bigWords, bigHint: isWords ? 'One word per line, in order. Type ' + ({ '-': 'a hyphen', ' ': 'a space', '.': 'a dot', '_': 'an underscore' }[(s.cfg[s.recipe] || {}).sep] || 'the separator') + ' between words.' : 'Groups of four, in order. Type them without spaces.',
      noSingle: noSingle, noOutput: noOutput,
      copied: s.copied, copyMain: () => (s.recipe === 'bulk' ? this.copyValue(s.bulk.join('\n'), 'main', s.bulk.length + ' passwords', true) : this.copyValue(s.password, 'main', 'Password', true)),
      copyIcon: s.copied ? I.Check : I.Copy, copyLabel: s.copied ? 'Copied' : (s.recipe === 'bulk' ? 'Copy all' : 'Copy'),
      regen: () => this.regen(), regenLabel: s.recipe === 'bulk' ? 'Cut ' + s.cfg.bulk.count + ' new' : 'Cut a new one',
      stubNote: s.recipe === 'wifi' ? 'Or let guests scan the QR below' : s.recipe === 'master' ? 'Then practise it below' : s.recipe === 'form' ? 'Checked against the rules below' : 'Lands in this tab’s drawer',
      showNext: s.copied && !e,
      copiedStr: s.copied ? 'true' : 'false',
      loreMood: lore[0], loreScene: lore[1], loreLine: lore[2],
      bLoreMood: s.breach === 'found' ? 'worried' : s.breach === 'notfound' ? 'happy' : 'flat', bLoreScene: s.breach === 'found' ? 'puddle' : s.breach === 'notfound' ? 'shield' : 'cloud',
      posterOpen: !!s.posterOpen, openPoster: () => this.setState({ posterOpen: true }), closePoster: () => this.setState({ posterOpen: false }), printPoster: () => { try { window.print(); } catch (x) {} }, posterSsid: s.cfg.wifi.ssid || '', posterPw: s.password,
      shareOpen: !!s.shareOpen, canShare: !e && !!m.bits, openShare: () => this.setState({ shareOpen: true, announce: 'Strength card open. It does not include the password.' }), closeShare: () => this.setState({ shareOpen: false }),
      shareWhat: s.recipe === 'pin' ? 'PIN' : (isWords ? 'passphrase' : 'password'), shareTime: shareTime, shareSub: tr.name + ' · ≈ ' + Math.round(m.bits) + ' bits · estimate · cut for ' + (defs.find((d) => d.id === s.recipe) || defs[0]).name,
      shareMood: tr.n >= 5 ? 'cool' : tr.n >= 4 ? 'proud' : tr.n >= 3 ? 'flat' : 'worried', shareScene: tr.n >= 5 ? 'sparkles' : tr.n >= 4 ? 'confetti' : 'none',
      shareAria: 'Strength card: my new password would take ' + shareTime + ' to guess. ' + tr.name + ', about ' + Math.round(m.bits) + ' bits. The password is not shown.',
      shareNow: () => this.shareCard(shareText, shareTime, tr, m, isWords),
      downloadCard: () => this.cardPng(shareTime, tr, m, isWords).then((b) => { if (!b) { this.toast('error', 'Couldn’t make the image here. Copy the text instead.'); return; } const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'passlore-strength.png'; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); this.toast('ok', 'Saved the strength card. The password isn’t on it.'); }),
      copyShareText: () => this.writeClip(shareText).then((ok) => this.toast(ok ? 'ok' : 'error', ok ? 'Share text copied — no password in it.' : 'Couldn’t reach the clipboard.')),
      nextSteps: steps,
      clearOn: s.clearOn ? 'true' : 'false', clearLabel: s.clearLeft > 0 ? 'Clipboard clears in 0:' + String(s.clearLeft).padStart(2, '0') : 'Clear clipboard in 60 s',
      toggleClear: () => { const on = !s.clearOn; this.setState({ clearOn: on }); if (on && s.copied) this.armClear(); if (!on) { clearInterval(this._clr); this.setState({ clearLeft: 0 }); } },
      tierTone: e ? 'var(--on-stage-2)' : tr.tone, tierIcon: e ? I.Question : tr.icon, tierName: e ? 'No estimate yet' : tr.name,
      tierBits: e ? '' : '≈ ' + Math.round(m.bits) + ' bits',
      crackLine: e ? 'Fix the rule above to get a password.' : 'Time to guess: ' + ck.text + (ck.cmp ? ' — ' + ck.cmp : ''),
      tierLineShort: e ? '' : tr.line,
      rulerPct: e ? '0%' : pct(ck.lg),
      marks: marks.map((k, i) => ({ label: k[0], pos: pct(k[1]), top: i % 2 ? '20px' : '0px' })),
      detail: s.detail, detailExp: s.detail ? 'true' : 'false', detailLabel: s.detail ? 'Hide the maths' : 'How is this worked out?', detailIcon: s.detail ? I.CaretUp : I.CaretDown, toggleDetail: () => this.setState({ detail: !s.detail }),
      formula: m.formula, notes: e ? [] : (m.notes || []), hasNote: !!s.note, note: s.note,
      tuneTitle: def.title, why: def.why,
      ctlLength: !!lenCfg, lenLabel: lenCfg ? lenCfg[0] : '', lenMin: lenCfg ? lenCfg[1] : 0, lenMax: lenCfg ? lenCfg[2] : 0, lenVal: lenCfg ? lenCfg[3] : 0, onLen: onLen,
      ctlQuick: s.recipe === 'quick', qSym: s.cfg.quick.symbols ? 'true' : 'false', qSim: s.cfg.quick.noSimilar ? 'true' : 'false',
      toggleQSym: () => this.setCfg('quick', { symbols: !s.cfg.quick.symbols }, s.cfg.quick.symbols ? 'Symbols off' : 'Symbols on'),
      toggleQSim: () => this.setCfg('quick', { noSimilar: !s.cfg.quick.noSimilar }, s.cfg.quick.noSimilar ? 'Look-alikes allowed' : 'Look-alikes dropped'),
      ctlForm: s.recipe === 'form', rulesText: s.cfg.form.text,
      onRules: (ev) => this.setCfg('form', { text: ev.target.value, ov: {} }, ''),
      rulesFound: p && p.found.length + chips.length ? 'Found in the text — tap × to ignore one' : 'No rules found yet — paste them above or set them here',
      ruleChips: chips,
      fMin: formR && formR.min != null ? formR.min : '', fMax: formR && formR.max != null ? formR.max : '', fSyms: formR ? (formR.noSymbols ? '' : (formR.syms != null ? formR.syms : C.S)) : '',
      onFMin: (ev) => { const v = parseInt(ev.target.value, 10); const ov = Object.assign({}, s.cfg.form.ov, { min: isNaN(v) ? null : v }); this.setCfg('form', { ov: ov }, ''); },
      onFMax: (ev) => { const v = parseInt(ev.target.value, 10); const ov = Object.assign({}, s.cfg.form.ov, { max: isNaN(v) ? null : v }); this.setCfg('form', { ov: ov }, ''); },
      onFSyms: (ev) => { const v = this.uniq(ev.target.value.replace(/[A-Za-z0-9\s]/g, '')); const ov = Object.assign({}, s.cfg.form.ov, { syms: v, noSymbols: v.length === 0 }); this.setCfg('form', { ov: ov }, ''); },
      needs: formR ? [['upper', 'Uppercase'], ['lower', 'Lowercase'], ['digit', 'Number'], ['symbol', 'Symbol'], ['startLetter', 'Starts with a letter']].map((n) => ({ label: n[1], on: formR[n[0]] ? 'true' : 'false', toggle: () => { const ov = Object.assign({}, s.cfg.form.ov); ov[n[0]] = !formR[n[0]]; this.setCfg('form', { ov: ov }, ''); } })) : [],
      fitBg: conflict ? 'var(--warning-soft)' : 'var(--success-soft)', fitTone: conflict ? 'var(--warning)' : 'var(--success)', fitIcon: conflict ? I.Warning : I.CheckCircle,
      fitTitle: conflict ? 'These rules can’t all be met' : 'Fits every rule',
      fitList: fitList.map((f) => ({ icon: f.ok ? I.Check : I.X, tone: f.ok ? 'var(--success)' : 'var(--danger)', text: f.text })),
      ctlWords: ['wifi'].indexOf(s.recipe) >= 0 || (s.recipe === 'custom' && c.kind === 'words'),
      seps: [['-', 'Hyphen', '-'], ['.', 'Dot', '.'], ['_', 'Underscore', '_'], [' ', 'Space', '␣']].map((q) => ({ glyph: q[2], name: q[1], aria: 'Between words: ' + q[1], sel: c.sep === q[0] ? 'true' : 'false', pick: () => this.setCfg(s.recipe, { sep: q[0] }, '') })),
      wordListLine: 'Words from the EFF long list — ' + this.W(s).length.toLocaleString('en-GB') + (s.wordList ? ' of its 7,776; “undefined” is left out because it reads like a bug' : ' for now (loading the full list…)') + '. The estimate assumes an attacker has the same list.',
      ctlWifi: s.recipe === 'wifi', ssid: ssid, onSsid: (ev) => this.setCfg('wifi', { ssid: ev.target.value }, ''),
      wifiLen: s.password.length + ' characters — inside Wi-Fi’s 8–63 limit',
      hasQr: !!qrPath, noQr: !qrPath, qrPath: qrPath, qrBox: '-4 -4 ' + (qrN + 8) + ' ' + (qrN + 8), qrAria: 'QR code to join ' + ssid, qrHint: ssid ? 'Drawing the QR…' : 'Add the network name to draw a QR code guests can scan', qrCaption: qrPath ? 'Scan to join ' + ssid : 'Drawn on this device',
      ctlMaster: s.recipe === 'master', practiceInput: practice.input,
      onPractice: (ev) => this.setState({ practice: Object.assign({}, practice, { input: ev.target.value }) }),
      checkPractice: checkPractice, hasPracticeMsg: !!practice.msg, practiceMsg: practice.msg, practiceTone: practice.ok ? 'var(--success)' : 'var(--warning)', practiceIcon: practice.ok ? I.CheckCircle : I.Warning,
      practiceDots: [0, 1, 2].map((i) => ({ bg: i < practice.hits ? 'var(--success)' : 'transparent' })), practiceAria: practice.hits + ' of 3 correct in a row',
      ctlPin: s.recipe === 'pin', pinSkip: s.cfg.pin.skip ? 'true' : 'false', togglePinSkip: () => this.setCfg('pin', { skip: !s.cfg.pin.skip }, ''),
      pinPicks: [4, 6, 8].map((n) => ({ n: n, sel: s.cfg.pin.digits === n ? 'true' : 'false', pick: () => this.setCfg('pin', { digits: n }, 'Digits ' + s.cfg.pin.digits + ' → ' + n) })),
      ctlBulk: s.recipe === 'bulk', count: s.cfg.bulk.count,
      onCount: (ev) => { const v = Math.max(1, Math.min(500, parseInt(ev.target.value, 10) || 1)); this.setCfg('bulk', { count: v }, ''); },
      countPicks: [10, 50, 200, 500].map((n) => ({ n: n, sel: n === s.cfg.bulk.count ? 'true' : 'false', pick: () => this.setCfg('bulk', { count: n }, '') })),
      formats: [['txt', '.txt'], ['csv', '.csv'], ['json', '.json']].map((f) => ({ name: f[1], sel: fmt === f[0] ? 'true' : 'false', pick: () => this.setState({ cfg: Object.assign({}, s.cfg, { bulk: Object.assign({}, s.cfg.bulk, { format: f[0] }) }) }) })),
      bulkRows: bulkRows, downloadLabel: 'Download ' + s.bulk.length + ' as .' + fmt,
      download: () => {
        const list = s.bulk; const name = 'passlore-' + list.length + '.' + fmt;
        const body = fmt === 'json' ? JSON.stringify({ count: list.length, passwords: list }, null, 2) : fmt === 'csv' ? 'n,password\n' + list.map((v, i) => (i + 1) + ',"' + v.replace(/"/g, '""') + '"').join('\n') + '\n' : list.join('\n') + '\n';
        try { const url = URL.createObjectURL(new Blob([body], { type: fmt === 'json' ? 'application/json' : fmt === 'csv' ? 'text/csv' : 'text/plain' })); const a = document.createElement('a'); a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 2000); } catch (x) {}
        this.toast('download', 'Saving ' + name + ' — a plain, unencrypted file. Delete it once everyone has theirs.');
      },
      copyAll: () => this.copyValue(s.bulk.join('\n'), 'all', s.bulk.length + ' passwords', true),
      ctlCustom: s.recipe === 'custom',
      showBuild: deckOf(s.recipe) === 'custom',
      buildKinds: [['random', 'Characters'], ['words', 'Words'], ['rules', 'Fit site rules'], ['many', 'Many at once']].map((k) => ({ name: k[1], sel: bk === k[0] ? 'true' : 'false', pick: () => pickBuild(k[0]) })),
      leakOpen: !!s.leakOpen, leakClosed: !s.leakOpen, leakExp: s.leakOpen ? 'true' : 'false', leakBtn: s.leakOpen ? 'Hide' : 'Open', toggleLeak: () => this.setState({ leakOpen: !s.leakOpen }),
      kindRandom: s.recipe === 'custom' && s.cfg.custom.kind === 'random',
      charOpts: [['upper', 'Uppercase', 'A B C … Z'], ['lower', 'Lowercase', 'a b c … z'], ['digits', 'Digits', '0 1 2 … 9'], ['symbols', 'Symbols', '! @ # $ % & …'], ['noSimilar', 'Avoid look-alikes', '0 O o 1 l I |']].map((d) => ({ id: 'cu-' + d[0], name: d[1], sample: d[2], on: s.cfg.custom[d[0]] ? 'true' : 'false', toggle: () => { const pp = {}; pp[d[0]] = !s.cfg.custom[d[0]]; this.setCfg('custom', pp, d[1] + (s.cfg.custom[d[0]] ? ' off' : ' on')); } })),
      exclude: s.cfg.custom.exclude, include: s.cfg.custom.include, prefix: s.cfg.custom.prefix, suffix: s.cfg.custom.suffix, pattern: s.cfg.custom.pattern,
      onExclude: (ev) => this.setCfg('custom', { exclude: ev.target.value }, 'Exclusions changed'),
      onInclude: (ev) => this.setCfg('custom', { include: ev.target.value }, ''),
      onPrefix: (ev) => this.setCfg('custom', { prefix: ev.target.value }, ''),
      onSuffix: (ev) => this.setCfg('custom', { suffix: ev.target.value }, ''),
      onPattern: (ev) => this.setCfg('custom', { pattern: ev.target.value }, ''),
      leakIntro: s.offline ? 'You’re offline. The check needs a connection; everything else works.' : (s.recipe === 'bulk' ? 'Checks the selected row (number ' + (s.bulkSel + 1) + '). ' : '') + 'Your browser hashes the password. Only the highlighted start of the hash is sent to Have I Been Pwned; the match happens here.',
      hashHead: hashFull ? hashFull.slice(0, 5) : '•••••', hashTail: hashFull ? hashFull.slice(5) : '•'.repeat(35), hashHeadLen: '5 characters', hashTailLen: '35 characters',
      bIdle: bState === 'idle', bChecking: bState === 'checking', bResult: bState === 'found' || bState === 'notfound' || bState === 'failed',
      checkDisabled: s.offline || noOutput, checkIcon: s.offline ? I.WifiSlash : I.Search, checkLabel: s.offline ? 'Needs a connection' : 'Check for leaks',
      check: () => {
        const cur = this.S(); if (!this.current(cur)) return;
        if (cur.offline) { this.setState({ breach: 'failed', failReason: 'offline', announce: 'Couldn’t check: offline. Unknown.' }); return; }
        this.setState({ breach: 'checking', leakOpen: true, announce: 'Checking leak data.' });
        clearTimeout(this._bt); this._bt = setTimeout(() => { const r = this.S().sim; this.setState({ breach: r, failReason: r === 'failed' ? 'service' : '', announce: bMap[r][0] }); }, 1300);
      },
      bTitle: b[0], bText: b[1], bTone: b[2], bSoft: b[3], bIcon: b[4], bFound: bState === 'found', bFailed: bState === 'failed',
      hasHistory: hist.length > 0, noHistory: hist.length === 0, historyRows: hist, historyCount: String(hist.length), historyDay: 'Today · ' + today,
      clearAll: () => { this.setState({ history: [], sheet: false }); this.toast('ok', 'Drawer emptied.'); },
      gens: s.gens,
      sheet: s.sheet, closeSheet: () => this.setState({ sheet: false }),
      faq: faq.map((f) => ({ q: f[0], a: f[1] })),
      hasToast: !!s.toast, toastText: s.toast ? s.toast.text : '', toastIcon: s.toast ? s.toast.icon : I.Info, dismissToast: () => this.setState({ toast: null }),
      showConsent: s.consent === 'pending',
      consentYes: () => { this.setState({ consent: 'done' }); this.toast('ok', 'Thanks — visits will be counted. Change it any time in Privacy.'); },
      consentNo: () => { this.setState({ consent: 'done' }); this.toast('ok', 'No analytics. Everything works the same.'); },
      consentLater: () => this.setState({ consent: 'later', announce: 'No analytics until you choose.' }),
      showTray: this.props.tray !== false, tray: s.tray, trayExp: s.tray ? 'true' : 'false', toggleTray: () => this.setState({ tray: !s.tray }), trayLabel: s.tray ? 'Hide controls' : 'Show controls',
      scenarios: scen.map((x) => ({ id: x[0], name: x[1], sel: x[0] === s.scenario })),
      onScenario: (ev) => { const nb = this.build(ev.target.value); nb.theme = this.S().theme; nb.tray = true; nb.wordList = this._loaded || null; if (this._loaded) Object.assign(nb, this.gen(nb)); this.setState(nb); this.hashOf(this.current(nb)).then((h) => this.setState({ hashFull: h })); },
      trayThemes: themeDefs.map((t) => ({ short: t[2], checked: t[0] === s.theme ? 'true' : 'false', border: t[0] === s.theme ? '2px solid #FFB79A' : '1px solid #7D776F', pick: pickTheme(t[0]) })),
      sims: [['found', 'Found'], ['notfound', 'Not found'], ['failed', 'No answer']].map((x) => ({ name: x[1], sel: s.sim === x[0] ? 'true' : 'false', border: s.sim === x[0] ? '2px solid #FFB79A' : '1px solid #7D776F', pick: () => this.setState({ sim: x[0] }) })),
      offlineOn: s.offline ? 'true' : 'false', toggleOffline: () => this.setState({ offline: !s.offline, breach: 'idle' })
    };
  }
}
