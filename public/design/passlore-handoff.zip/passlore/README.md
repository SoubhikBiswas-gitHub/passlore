# Passlore — design handoff (standalone HTML)

This folder is the complete Passlore redesign as plain files: static HTML screens, design-system boards, a runnable prototype, design tokens, mascot SVGs and the behaviour code. It is written for a developer (or Claude Code) building the real site with **Next.js 16, Tailwind CSS 4, shadcn/ui, Phosphor icons and Framer Motion**.

Open `index.html` in a browser to browse everything.

---

## What's in here

| Folder / file | What it is | How to use it |
|---|---|---|
| `index.html` | Gallery of every screen and board | Start here |
| `screens/*.html` | 40 **static, responsive** snapshots of the product (no JavaScript). Each one is a single self-contained HTML file with all its CSS inline. Resize the browser window to see phone / tablet / desktop layouts. | The visual source of truth for each page and state |
| `boards/*.html` | 13 design-system and strategy boards (1440 px wide): direction, recipes, growth, brand, colour, type, icons, components, signature components, illustration, site chrome | Specs: tokens, states, rules |
| `prototype/` | The **interactive** prototype (all buttons work). Needs a local web server — see below | Check behaviour and motion |
| `reference/tokens.css` | Every colour, font and motion token for the 5 themes as CSS custom properties | Copy into `app/globals.css` (Tailwind 4 `@theme`) |
| `reference/lore/*.svg` | Lore the mascot: 8 moods + 6 scenes as standalone SVGs | Turn into a `<Lore mood scene />` React component |
| `reference/logic/*.logic.js` | The behaviour code: password generation, strength maths, site-rules parser, leak check, share-card image, page copy | Port the pure functions as-is |

Fonts load from Google Fonts (Sora, Plus Jakarta Sans, JetBrains Mono). Offline, the screens fall back to system fonts but keep their layout.

### Run the interactive prototype

```bash
cd prototype
python3 -m http.server 8000      # or: npx serve .
# open http://localhost:8000/Generator.dc.html
```

Other entry points: `About.dc.html` (prop `page` = about | blog | article | privacy | terms | 404), `DSIllustration.dc.html`, `Growth.dc.html`. `support.js` is the small runtime that renders the `.dc.html` component files; it is only needed for the prototype, not for the real build. The prototype has a dashed "Prototype controls" strip at the top: it is review tooling, not product UI.

---

## The product in one paragraph

Passlore is a free, open-source password generator that runs entirely in the browser. Instead of asking *how* you want a password, it asks **where it's going** and sets itself up: **Just one** (preselected), **Password manager**, **Wi-Fi**, **PIN**, **Build your own** (modes: Characters, Words, Fit site rules, Many at once). The password appears on a "ticket" with a tear-off stub holding **Copy** and **Cut a new one**. Below it: a strength estimate in plain words, one settings panel for the chosen recipe, an optional leak check, and a drawer of this tab's passwords. Nothing is ever sent to a server.

## Non-negotiables (keep these when building)

- **Honesty.** Strength numbers are computed, never typed in, and always labelled as estimates ("average time at 100 billion guesses a second"). A leak check that is "not found" says *a good sign, not proof*; a failed check says *unknown* and is never shown as safe. The "1,284 times" leak count in the prototype is **simulated**; the SHA-1 hash and the 5-character prefix are real.
- **Privacy.** Passwords, pasted site rules, network names and practice typing never leave the page. The leak check sends only the first 5 of 40 SHA-1 hex characters to Have I Been Pwned's range API (use the `Add-Padding: true` header), and only when the user presses Check.
- **Accessibility (WCAG 2.2 AA).** Every text pair ≥ 4.5 : 1 (non-text ≥ 3 : 1), targets ≥ 44 px, no text under 12 px, visible focus, `prefers-reduced-motion` stops all decorative motion, a live region announces copy / new password / results. Volt lime is never text on white.
- **Placeholders** in [BRACKETS] must be filled by the operator: [REPO URL], [ISSUES URL], [SECURITY EMAIL], [ANALYTICS PROVIDER], [DATA COLLECTED], [HOSTING PROVIDER], [RETENTION PERIOD], [CONTACT EMAIL], [COMPANY NAME], [DATE], [AUTHOR], [PUBLISH DATE], [N] min read.

## Visual system

- **Palette "Volt"** — electric blue `#2447F5` for anything you act on (Copy, links, toggles, sliders, focus); volt lime `#C8FF2E` for the selected recipe card (with a 5 px electric-blue "sticker" shadow and a dark outline) and the highlighter on the headline; ink `#0B0D17` text on a white page. **Dark theme** (`#0A0C14`) swaps them: lime buttons with ink text, blue selected card with white text. Sepia and high contrast are in `tokens.css`. Strength / leak results use green / amber / red, always with a word and an icon.
- **Type** — Sora (display: headlines, recipe names, numbers), Plus Jakarta Sans (all UI and reading), JetBrains Mono (passwords only; distinguishes 0/O and 1/l/I). Digits in the password are blue, symbols rust orange, letters ink — a reading aid only; "Spell it out" names every character.
- **The ticket** — a white card, 24 px radius, two 13 px notches cut into the top and bottom edge where the stub starts (CSS `mask` with two radial gradients), a dotted 2 px divider, and a soft `drop-shadow` on a wrapper (box-shadow would be clipped by the mask). On phones it stacks, the notches go and the divider becomes horizontal; Copy and New move to a sticky thumb dock.
- **Copy feedback** — the Copy button turns green with ✓ "Copied" and throws a 750 ms burst of six small squares and dots (no stamp — it covered text). Then a "next steps" strip appears (3 steps per recipe + optional 60-second clipboard clear).
- **Lore the mascot** — a small key with a big face (volt bow, blue shaft, ink outline — fixed colours in every theme). Moods map to the computed state: worried (very weak / weak), unsure (fair), happy (strong), cool with sunglasses (very strong), proud + confetti (just copied), shocked (rules contradict), wink (password hidden), sleepy (empty drawer). Scenes: shield (not found), puddle (found in a leak), cloud (couldn't check / offline), drawer, lock (404), dice (how it works). A speech bubble next to Lore restates the result in words. Gentle bob + blink; all off under reduced motion.
- **No background patterns** and no tinted bands — clean white stage.

## Key behaviours (see `reference/logic/generator.logic.js`)

- Randomness: `crypto.getRandomValues` + **rejection sampling** (`rnd(n)`), never `Math.random` for secrets.
- Strength: entropy bits = `log2(pool) × length` (words: `log2(list) × words`; site rules: Monte-Carlo estimate over 600 samples). Tiers: < 28 very weak, < 50 weak, < 70 fair, < 100 strong, ≥ 100 very strong. Time to guess = `2^(bits−1) / 1e11` seconds, phrased with landmarks (lifetime, recorded history, humans, Earth, age of the universe).
- Recipes: Just one = 16 chars from 89 (symbols on); Manager = 32 chars; Wi-Fi = 6 EFF long-list words joined by hyphens + QR code (`WIFI:T:WPA;S:…;P:…;;`, qrcode-generator, MIT) + "Show big" + printable **guest poster**; PIN = 6 digits, obvious PINs skipped; Build your own → Characters (all toggles, exclude/include, prefix/suffix), Words (3–10), **Fit site rules** (paste rules → parsed into chips → longest password they allow + ✓ fit checklist; contradictions get a conflict card with a one-tap fix), Many at once (up to 500, .txt / .csv / .json export, warned as unencrypted).
- The EFF list is 7,775 words: "undefined" is removed because it reads like a bug in a password.
- **Share the strength** — a 1200 × 630 card: "My new password would take ≈ 2.5 trillion years to guess", tier, bits, Lore, passlore.com — never the password. Share sheet with the PNG when the browser supports files, else Save image / Copy text (`cardSvg` → canvas → PNG in the logic file).
- Drawer: this tab only (sessionStorage), last 20, masked, press-and-hold to peek, copy without revealing.
- Consent: analytics off until the user says "Allow"; the site works the same either way.

## Suggested build structure (Next.js 16)

```
app/
  layout.tsx            fonts (next/font: Sora, Plus_Jakarta_Sans, JetBrains_Mono), theme script, <Header/> <Footer/>
  page.tsx              Generator
  how-it-works/page.tsx
  blog/page.tsx, blog/[slug]/page.tsx
  privacy/page.tsx, terms/page.tsx, not-found.tsx
components/
  generator/RecipeDeck.tsx  Ticket.tsx  CopyButton.tsx  StrengthRuler.tsx  NextSteps.tsx
  generator/RecipePanel.tsx (+ panels per recipe)  LeakCheck.tsx  Drawer.tsx  ShareCard.tsx  WifiPoster.tsx
  Lore.tsx              props: mood, scene, size, label
lib/
  random.ts  strength.ts  recipes.ts  siteRules.ts  wordlist.ts  leakCheck.ts  shareCard.ts
```

Use shadcn/ui primitives for Dialog (share card, poster, drawer as Sheet), RadioGroup (recipe deck — one tab stop, arrow keys), Switch, Slider, Tabs, Tooltip; Phosphor icons named on `boards/DSIcons.html`; Framer Motion only for the roll-in (≤ 520 ms), the copy burst, sheet/dialog rises and Lore's idle — all wrapped in `useReducedMotion()`.

## Screen index

`screens/` — generator (first visit, ready, copied, every recipe, site rules + contradiction, many at once, strength detail, spelled out, hidden, leak check: running / found / not found / couldn't check, offline, drawer + empty drawer, share card, Wi-Fi poster, Show big, theme menu), dark / sepia / high-contrast variants, and the pages How it works (light + dark), Blog, Article, Privacy, Terms, 404 (light + dark).
